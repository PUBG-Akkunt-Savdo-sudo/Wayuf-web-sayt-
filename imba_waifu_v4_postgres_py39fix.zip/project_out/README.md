# 🌸 IMBA WAIFU — Production Deploy Guide

## Arxitektura

```
Telegram Bot  →  FastAPI Backend  →  PostgreSQL
                      ↕
               Telegram Mini App (GitHub Pages)
```

---

## 🚀 Birinchi marta o'rnatish (Ubuntu VPS)

### 1. Loyihani serverga yuklash
```bash
scp -r imba_waifu_v4_fullstack.zip root@SERVER_IP:/root/
ssh root@SERVER_IP
cd /root && unzip imba_waifu_v4_fullstack.zip && cd project_out
```

### 2. PostgreSQL o'rnatish
```bash
sudo bash setup_postgres.sh
```
Script tugagach parolni ko'chirib oling!

### 3. .env faylini to'ldirish
```bash
cp .env.example .env
nano .env
```
```ini
BOT_TOKEN=YOUR_BOT_TOKEN
OWNER_TELEGRAM_ID=YOUR_TELEGRAM_ID
DATABASE_URL=postgresql://waifu:PAROL@127.0.0.1:5432/imbawaifu
MINIAPP_URL=https://your-github.github.io/your-repo/
CORS_ORIGINS=https://your-github.github.io
```

### 4. Eski SQLite ma'lumotlarini ko'chirish (agar bor bo'lsa)
```bash
pip install sqlalchemy psycopg2-binary python-dotenv --break-system-packages
python migrate_sqlite_to_postgres.py
```

### 5. Ishga tushirish
```bash
bash deploy.sh
```

---

## 🔄 Yangilanish (keyingi safar)
```bash
cd /root/project_out
git pull  # yoki yangi ZIP yuklang
bash deploy.sh
```

---

## 📊 Holat tekshirish
```bash
screen -ls                     # barcha screen sessionlar
screen -r wayuf_backend        # backend loglari
screen -r wayuf_bot            # bot loglari
screen -r wayuf_tunnel         # tunnel URL
curl http://localhost:8000/api/health  # API ishlayaptimi
```

---

## 🗄️ PostgreSQL boshqaruvi
```bash
sudo -u postgres psql imbawaifu    # DB ga kirish
\dt                                 # jadvallar ro'yxati
SELECT COUNT(*) FROM users;         # foydalanuvchilar soni
\q                                  # chiqish
```

---

## ⚠️ Xavfsizlik tekshiruvi

| Nima | Holat |
|------|-------|
| initData server tomonida HMAC tekshiruvi | ✅ |
| Balans faqat server tomonida o'zgartiriladi | ✅ |
| market_service `WITH FOR UPDATE` qulfi | ✅ |
| Demo fallback frontend'da yo'q | ✅ |
| Admin endpoint uchun alohida auth | ✅ |
| PostgreSQL connection pool | ✅ |
| Anti-cheat daily limits | ✅ |
| BOT_TOKEN .env'da (kodda emas) | ✅ |

---

## 📁 Fayl tuzilmasi
```
project_out/
├── .env.example          ← muhim sozlamalar namunasi
├── setup_postgres.sh     ← PostgreSQL avtomatik o'rnatish
├── migrate_sqlite_to_postgres.py  ← ma'lumot ko'chirish
├── deploy.sh             ← to'liq deploy skripti
├── backend/
│   ├── requirements.txt  ← psycopg2-binary qo'shilgan
│   ├── alembic.ini
│   └── app/
│       ├── core/
│       │   ├── config.py    ← majburiy o'zgaruvchilar tekshiruvi
│       │   ├── database.py  ← PostgreSQL connection pool
│       │   └── security.py  ← Telegram HMAC tekshiruvi
│       └── services/
│           ├── market_service.py   ← WITH FOR UPDATE qulflari
│           └── economy_service.py  ← anti-cheat, admin_adjust
├── bot/
└── miniapp/
    └── src/
        └── app.js  ← demo fallback yo'q, proper error screens
```
