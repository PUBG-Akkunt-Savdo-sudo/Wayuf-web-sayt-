/* ================= IMBA WAIFU — Admin Panel ================= */
const API_BASE = window.IMBA_API_BASE || 'https://YOUR-BACKEND-DOMAIN/api';

const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor('#0a0518'); } catch (e) {} }
const INIT_DATA = tg?.initData || '';

async function api(path, options = {}) {
  const res = await fetch(API_BASE + path, {
    ...options,
    headers: { 'Content-Type': 'application/json', 'X-Telegram-Init-Data': INIT_DATA, ...(options.headers || {}) },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `HTTP ${res.status}`);
  }
  return res.json();
}

function fmt(n) { return Number(n || 0).toLocaleString('ru-RU'); }
let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg; el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}

/* ---- Tab switching ---- */
document.getElementById('admTabs').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-tab]');
  if (!btn) return;
  document.querySelectorAll('#admTabs .tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.aview').forEach(v => v.classList.toggle('active', v.dataset.tab === btn.dataset.tab));
  loadTab(btn.dataset.tab);
});

const loaded = new Set();
function loadTab(tab) {
  if (tab === 'dashboard') loadDashboard();
  if (tab === 'users') loadUsers();
  if (tab === 'cards') { loadCards(); loadDrops(); }
  if (tab === 'market') loadMarket();
  if (tab === 'payments') { loadTransactions(); loadSettingsStatus(); }
  if (tab === 'chat') loadChatMod();
}

/* ---- Dashboard ---- */
async function loadDashboard() {
  try {
    const d = await api('/admin/dashboard');
    document.getElementById('dashStats').innerHTML = `
      <div class="statbox"><span>👥</span><b>${fmt(d.total_users)}</b><small>Users</small></div>
      <div class="statbox"><span>🗂</span><b>${fmt(d.total_cards)}</b><small>Cards</small></div>
      <div class="statbox"><span>💰</span><b>${fmt(d.market_volume_7d_ball)}</b><small>Market 7d (Ball)</small></div>`;
    document.getElementById('dashActivity').innerHTML = d.recent_activity.map(a =>
      `<li><span>${a.type} · ${a.currency}</span><b>${a.amount > 0 ? '+' : ''}${fmt(a.amount)}</b></li>`
    ).join('') || '<li>Hozircha faoliyat yo\'q</li>';
  } catch (e) { toast(e.message); }
}

/* ---- Users ---- */
let usersCache = [];
async function loadUsers() {
  try {
    usersCache = await api('/admin/users');
    document.getElementById('usersStats').innerHTML = `<div class="sbox"><b>${usersCache.length}</b><small>Jami (so'nggi 200)</small></div>`;
    renderUsers(usersCache);
  } catch (e) { toast(e.message); }
}
function renderUsers(list) {
  document.getElementById('usersList').innerHTML = list.map(u => `
    <div class="listrow">
      <div class="thumb">${u.is_admin ? '👑' : '👤'}</div>
      <div class="info"><b>${u.name}</b><small>ID: ${u.telegram_id} · Lv.${u.level} · 🪙${fmt(u.ball)}${u.banned ? ' · BANNED' : ''}</small></div>
      <button class="actbtn" data-adjust="${u.id}">+1000🪙</button>
      <button class="actbtn sell" data-ban="${u.id}" data-banned="${u.banned}">${u.banned ? 'Unban' : 'Ban'}</button>
    </div>`).join('') || '<p class="hint">Foydalanuvchi topilmadi</p>';
}
document.getElementById('userSearch').addEventListener('input', (e) => {
  const q = e.target.value.toLowerCase();
  renderUsers(usersCache.filter(u => u.name.toLowerCase().includes(q) || String(u.telegram_id).includes(q)));
});
document.getElementById('usersList').addEventListener('click', async (e) => {
  const adjustId = e.target.closest('[data-adjust]')?.dataset.adjust;
  if (adjustId) {
    try { await api(`/admin/users/${adjustId}/balance`, { method: 'POST', body: JSON.stringify({ currency: 'ball', amount: 1000 }) }); toast('Balans yangilandi'); loadUsers(); }
    catch (err) { toast(err.message); }
  }
  const banBtn = e.target.closest('[data-ban]');
  if (banBtn) {
    const isBanned = banBtn.dataset.banned === 'true';
    try { await api(`/admin/users/${banBtn.dataset.ban}/${isBanned ? 'unban' : 'ban'}`, { method: 'POST' }); toast(isBanned ? 'Unban qilindi' : 'Ban qilindi'); loadUsers(); }
    catch (err) { toast(err.message); }
  }
});

/* ---- Cards + AI ---- */
let generatedImageDataUrl = null;
document.getElementById('btnGenerate').addEventListener('click', async () => {
  const name = document.getElementById('aiName').value.trim();
  if (!name) { toast('Karta nomini kiriting'); return; }
  const btn = document.getElementById('btnGenerate');
  btn.disabled = true; btn.textContent = 'Yaratilmoqda...';
  try {
    const res = await api('/admin/cards/generate-image', {
      method: 'POST',
      body: JSON.stringify({
        name, anime: document.getElementById('aiAnime').value.trim(),
        rarity: document.getElementById('aiRarity').value,
        extra_prompt: document.getElementById('aiExtra').value.trim(),
      }),
    });
    generatedImageDataUrl = res.image_data_url;
    document.getElementById('aiPreview').src = generatedImageDataUrl;
    document.getElementById('aiPreviewWrap').hidden = false;
    document.getElementById('aiHint').textContent = 'Rasm tayyor — pastdagi "Karta yaratish" formasida shu nom bilan saqlang.';
    document.getElementById('cName').value = name;
    document.getElementById('cAnime').value = document.getElementById('aiAnime').value;
    document.getElementById('cRarity').value = document.getElementById('aiRarity').value;
    toast('Rasm yaratildi!');
  } catch (e) { toast(e.message); document.getElementById('aiHint').textContent = 'Xato: ' + e.message; }
  btn.disabled = false; btn.textContent = "✨ AI orqali rasm yaratish";
});

document.getElementById('btnCreateCard').addEventListener('click', async () => {
  const code = document.getElementById('cCode').value.trim();
  const name = document.getElementById('cName').value.trim();
  if (!code || !name) { toast('Kod va nomni kiriting'); return; }
  try {
    await api('/admin/cards', {
      method: 'POST',
      body: JSON.stringify({
        code, name, anime: document.getElementById('cAnime').value.trim(),
        rarity: document.getElementById('cRarity').value,
        base_price_ball: Number(document.getElementById('cPriceBall').value || 1000),
        base_price_diamond: Number(document.getElementById('cPriceDiamond').value || 0),
        image_url: generatedImageDataUrl || '',
      }),
    });
    toast('Karta yaratildi!');
    generatedImageDataUrl = null;
    document.getElementById('aiPreviewWrap').hidden = true;
    loadCards();
  } catch (e) { toast(e.message); }
});

async function loadCards() {
  try {
    const cards = await api('/cards');
    document.getElementById('cardsGrid').innerHTML = cards.map(c => `
      <div class="cardtile r-${c.rarity}">
        <div class="cardart" style="${c.image_url ? `background-image:url('${c.image_url}');background-size:cover;background-position:center` : ''}">
          <span class="rarity-tag">${c.rarity.toUpperCase()}</span>
          ${c.image_url ? '' : '🃏'}
        </div>
        <div class="cardbody"><b>${c.name}</b><div class="cardprice">🪙 ${fmt(c.base_price_ball)}</div></div>
      </div>`).join('');
    document.getElementById('featureCardSelect').innerHTML = cards.map(c =>
      `<option value="${c.id}">${c.name} (${c.rarity})</option>`).join('');
  } catch (e) { toast(e.message); }
}

document.getElementById('btnFeature').addEventListener('click', async () => {
  const cardId = document.getElementById('featureCardSelect').value;
  if (!cardId) { toast('Karta tanlang'); return; }
  try {
    await api(`/admin/cards/${cardId}/feature`, { method: 'POST', body: JSON.stringify({ hours: 24 }) });
    toast('E\'lon qilindi! 24 soat davomida faol.');
    loadDrops();
  } catch (e) { toast(e.message); }
});

async function loadDrops() {
  try {
    const drops = await api('/admin/drops');
    document.getElementById('dropsList').innerHTML = drops.map(d => {
      const endsIn = new Date(d.ends_at) - Date.now();
      const label = d.status === 'active' ? `Faol · qoldi ${Math.max(0, Math.round(endsIn / 60000))} daq`
        : d.status === 'retired' ? 'Chiqib ketdi'
        : 'Qaytdi (yangi tsikl boshlandi)';
      return `<div class="listrow">
        <div class="info"><b>${d.card?.name || '?'}</b><small>${label}${d.auto_decided ? ' · avtomatik hal qilindi' : ''}</small></div>
        ${d.status === 'active' ? `
          <button class="actbtn" data-resolve="${d.id}" data-decision="return">Majburan qaytarish</button>
          <button class="actbtn sell" data-resolve="${d.id}" data-decision="retire">Majburan chiqarish</button>` : ''}
      </div>`;
    }).join('') || '<p class="hint">Hozircha drop yo\'q</p>';
  } catch (e) { toast(e.message); }
}
document.getElementById('dropsList')?.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-resolve]');
  if (!btn) return;
  try {
    await api(`/admin/drops/${btn.dataset.resolve}/resolve`, { method: 'POST', body: JSON.stringify({ decision: btn.dataset.decision }) });
    toast('Hal qilindi'); loadDrops();
  } catch (err) { toast(err.message); }
});

/* ---- Market ---- */
async function loadMarket() {
  try {
    const m = await api('/admin/market');
    document.getElementById('marketStats2').innerHTML = `
      <div class="statbox"><span>📋</span><b>${fmt(m.active_listings)}</b><small>Active listings</small></div>
      <div class="statbox"><span>💰</span><b>${fmt(m.volume_7d_ball)}</b><small>Volume 7d</small></div>
      <div class="statbox"><span>📊</span><b>${fmt(m.avg_price_7d_ball)}</b><small>Avg price 7d</small></div>`;
    document.getElementById('marketNote').textContent = m.note || '';
  } catch (e) { toast(e.message); }
}

/* ---- Payments / Security ---- */
async function loadSettingsStatus() {
  try {
    const rows = await api('/admin/settings');
    const gemini = rows.find(r => r.key === 'gemini_api_key');
    document.getElementById('keyStatus').textContent = gemini?.is_set ? '✅ Kalit sozlangan' : '⚠️ Kalit hali kiritilmagan';
  } catch (e) { toast(e.message); }
}
document.getElementById('btnSaveKey').addEventListener('click', async () => {
  const value = document.getElementById('geminiKey').value.trim();
  if (!value) { toast('Kalitni kiriting'); return; }
  try {
    await api('/admin/settings', { method: 'POST', body: JSON.stringify({ key: 'gemini_api_key', value }) });
    toast('Saqlandi'); document.getElementById('geminiKey').value = '';
    loadSettingsStatus();
  } catch (e) { toast(e.message); }
});
async function loadTransactions() {
  try {
    const rows = await api('/admin/transactions');
    document.getElementById('txList').innerHTML = rows.map(t => `
      <div class="listrow">
        <div class="thumb">${t.amount > 0 ? '🟢' : '🔴'}</div>
        <div class="info"><b>${t.type}</b><small>user#${t.user_id} · ${t.currency}</small></div>
        <span class="price">${t.amount > 0 ? '+' : ''}${fmt(t.amount)}</span>
      </div>`).join('') || '<p class="hint">Tranzaksiya yo\'q</p>';
  } catch (e) { toast(e.message); }
}

/* ---- Chat / Broadcast ---- */
document.getElementById('btnBroadcast').addEventListener('click', async () => {
  const text = document.getElementById('bcText').value.trim();
  if (!text) { toast('Xabar matnini kiriting'); return; }
  const btn = document.getElementById('btnBroadcast');
  btn.disabled = true; btn.textContent = 'Yuborilmoqda...';
  try {
    const res = await api('/admin/broadcast', { method: 'POST', body: JSON.stringify({ text, target: document.getElementById('bcTarget').value }) });
    document.getElementById('bcResult').textContent = `Yuborildi: ${res.sent}/${res.total} (xato: ${res.failed})`;
    toast('Broadcast yakunlandi');
  } catch (e) { toast(e.message); }
  btn.disabled = false; btn.textContent = 'Yuborish';
});
async function loadChatMod() {
  try {
    const rows = await api('/admin/chat');
    document.getElementById('admChatList').innerHTML = rows.map(m => `
      <div class="listrow">
        <div class="info"><b>${m.name}</b><small>${m.text}</small></div>
        <button class="actbtn sell" data-delmsg="${m.id}">O'chirish</button>
      </div>`).join('') || '<p class="hint">Xabar yo\'q</p>';
  } catch (e) { toast(e.message); }
}
document.getElementById('admChatList')?.addEventListener('click', async (e) => {
  const id = e.target.closest('[data-delmsg]')?.dataset.delmsg;
  if (!id) return;
  try { await api(`/admin/chat/${id}`, { method: 'DELETE' }); toast('O\'chirildi'); loadChatMod(); }
  catch (err) { toast(err.message); }
});

/* ---- Init ---- */
if (!INIT_DATA) {
  toast('Bu panel faqat Telegram ichida ishlaydi');
} else {
  loadDashboard();
}
