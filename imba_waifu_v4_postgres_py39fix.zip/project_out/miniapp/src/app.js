/* ═══════════════════════════════════════════════════════════════
   IMBA WAIFU — Production Frontend v4.0
   ✅ No demo fallback
   ✅ initData enforced
   ✅ Backend-down error screen
   ✅ All fake data removed
═══════════════════════════════════════════════════════════════ */

const BASE = window.IMBA_API_BASE || '/api';

const VIEW_ORDER   = ['home','cards','market','games','chat','profile','admin'];
const RARITY_EMOJI = { Ordinary:'⚪', Rare:'🔵', Special:'🟢', Legend:'🟡', Galaxy:'🟣', Unique:'🔴' };
const RARITY_CLR   = { Ordinary:'#c6ccdd', Rare:'#8ec4ff', Special:'#4fd6e8', Legend:'#ffc857', Galaxy:'#c04dff', Unique:'#ff5c92' };

/* ── App state ─────────────────────────────────────────────── */
let initData = '';
let ME       = null;   // NEVER assigned fake data — always from server
let WS       = null;
let wsRoom   = 'global';
let lastView = 'home';
let allCards = [];
let myCards  = [];
let cardMode = 'all';

/* ── Tiny utils ─────────────────────────────────────────────── */
const $   = id  => document.getElementById(id);
const qs  = s   => document.querySelector(s);
const qsa = s   => [...document.querySelectorAll(s)];
const fmt = n   => Number(n || 0).toLocaleString();
const esc = s   => { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; };

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls)  e.className = cls;
  if (html) e.innerHTML = html;
  return e;
}

/* ── Toast ─────────────────────────────────────────────────── */
function toast(msg, type = 'info', dur = 3000) {
  const t = $('toast');
  t.textContent = msg;
  t.className   = `toast show toast-${type}`;
  clearTimeout(t._t);
  t._t = setTimeout(() => t.classList.remove('show'), dur);
}

/* ═══════════════════════════════════════════════════════════════
   API — single entry point, always authenticated
═══════════════════════════════════════════════════════════════ */
async function api(path, method = 'GET', body = null) {
  const headers = { 'Content-Type': 'application/json' };
  if (initData) headers['X-Telegram-Init-Data'] = initData;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);

  let r;
  try {
    r = await fetch(BASE + path, opts);
  } catch (networkErr) {
    throw new Error('Tarmoq xatosi: serverga ulanib bo\'lmadi');
  }

  if (!r.ok) {
    const err = await r.json().catch(() => ({ detail: r.statusText }));
    throw new Error(err.detail || `Server xatosi: ${r.status}`);
  }
  return r.json();
}

/* ═══════════════════════════════════════════════════════════════
   BOOTSTRAP
═══════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', async () => {
  /* 1 ─ Telegram WebApp */
  const tg = window.Telegram?.WebApp;
  if (tg) {
    tg.ready();
    tg.expand();
    tg.setHeaderColor?.('#0a0518');
    tg.setBackgroundColor?.('#0a0518');
    initData = tg.initData || '';
  }

  /* 2 ─ Guard: must be opened inside Telegram */
  if (!initData) {
    showFatalError(
      '📱 Telegram orqali oching',
      'Bu mini-ilova faqat Telegram ichida ishlaydi.\nIltimos, botni oching va "App" tugmasini bosing.',
      false   // no retry
    );
    return;
  }

  /* 3 ─ Snow & interactions */
  initSnow();
  setupRipple();
  setupNav();

  /* 4 ─ Load user (the ONLY source of truth) */
  showLoadingScreen();
  try {
    ME = await api('/users/me');
  } catch (e) {
    hideLoadingScreen();
    showFatalError(
      '🔌 Server bilan bog\'lanib bo\'lmadi',
      `${e.message}\n\nBackend ishlamayapti yoki tarmoq muammosi bor. Qaytadan urinib ko'ring.`,
      true   // show retry button
    );
    return;
  }

  hideLoadingScreen();
  renderTopbar();
  renderLevelBar();
  $('adminNavBtn').hidden = !ME.is_admin;
  navTo('home');
});

/* ── Loading screen ─────────────────────────────────────────── */
function showLoadingScreen() {
  let s = $('loadingScreen');
  if (!s) {
    s = el('div', '', `
      <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;
                  min-height:100dvh;gap:18px;padding:30px;text-align:center">
        <div style="font-size:52px;animation:heroFloat 2s ease-in-out infinite">🌸</div>
        <b style="font-family:'Baloo 2',sans-serif;font-size:22px;color:#c891ff">IMBA WAIFU</b>
        <div style="width:200px;height:4px;border-radius:99px;background:#1a1338;overflow:hidden">
          <div style="height:100%;background:linear-gradient(90deg,#7a2bf5,#c04dff,#ff9be0,#c04dff,#7a2bf5);
                      background-size:200% 100%;animation:xpShimmer 1.5s linear infinite;border-radius:99px"></div>
        </div>
        <small style="color:#8f88b8;font-size:11px">Yuklanmoqda...</small>
      </div>`);
    s.id = 'loadingScreen';
    s.style.cssText = 'position:fixed;inset:0;z-index:999;background:var(--bg)';
    document.body.appendChild(s);
  }
  s.hidden = false;
}

function hideLoadingScreen() {
  const s = $('loadingScreen');
  if (s) { s.style.opacity = '0'; s.style.transition = 'opacity .3s'; setTimeout(() => s.remove(), 350); }
}

/* ── Fatal error screen ─────────────────────────────────────── */
function showFatalError(title, msg, canRetry = true) {
  let s = $('fatalScreen');
  if (s) s.remove();
  s = el('div', '', `
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;
                min-height:100dvh;gap:16px;padding:30px;text-align:center;max-width:360px;margin:0 auto">
      <div style="font-size:48px">😔</div>
      <b style="font-family:'Baloo 2',sans-serif;font-size:18px;color:#f1eefc">${esc(title)}</b>
      <p style="color:#8f88b8;font-size:13px;line-height:1.5;white-space:pre-line">${esc(msg)}</p>
      ${canRetry ? `<button onclick="location.reload()" style="background:linear-gradient(135deg,#7a2bf5,#c04dff);
        color:#fff;border:none;border-radius:14px;padding:13px 28px;font-size:14px;font-weight:800;cursor:pointer;
        font-family:inherit">🔄 Qaytadan urinish</button>` : ''}
    </div>`);
  s.id = 'fatalScreen';
  s.style.cssText = 'position:fixed;inset:0;z-index:998;background:var(--bg)';
  document.body.appendChild(s);
}

/* ═══════════════════════════════════════════════════════════════
   TOPBAR & LEVEL
═══════════════════════════════════════════════════════════════ */
function renderTopbar() {
  if (!ME) return;
  const av = $('avatarInitial');
  if (ME.avatar_url) {
    av.style.cssText = `background-image:url(${ME.avatar_url});background-size:cover;background-position:center`;
    av.textContent   = '';
  } else {
    av.style.cssText = '';
    av.textContent   = (ME.name || '?')[0].toUpperCase();
  }
  $('topName').textContent     = ME.name || '—';
  $('topRank').textContent     = ME.rank_title || 'Newbie';
  $('balDiamond').textContent  = fmt(ME.diamond);
  $('balBall').textContent     = fmt(ME.ball);
  $('keyBadge').textContent    = ME.keys || 0;
  $('keyBadge2').textContent   = ME.keys || 0;
}

function renderLevelBar() {
  if (!ME) return;
  $('lvNum').textContent  = `Lv. ${ME.level}`;
  $('lvRank').textContent = ME.rank_title || 'Newbie';
  const pct = Math.min(100, (ME.xp / (ME.xp_next || 1)) * 100);
  $('xpFill').style.width = pct + '%';
  $('xpText').textContent = `${fmt(ME.xp)} / ${fmt(ME.xp_next)} XP`;
}

/* ═══════════════════════════════════════════════════════════════
   NAVIGATION
═══════════════════════════════════════════════════════════════ */
function setupNav() {
  qsa('.navbtn[data-view]').forEach(b => b.addEventListener('click', () => navTo(b.dataset.view)));
  qsa('.qbtn[data-view]').forEach(b   => b.addEventListener('click', () => navTo(b.dataset.view)));
  qsa('.qbtn[data-action]').forEach(b => b.addEventListener('click', () => handleQuickAction(b.dataset.action)));
}

function navTo(name) {
  const pi = VIEW_ORDER.indexOf(lastView);
  const ni = VIEW_ORDER.indexOf(name);
  qsa('.view').forEach(v => v.classList.remove('active', 'slide-back'));
  const target = qs(`.view[data-view="${name}"]`);
  if (!target) return;
  target.classList.add('active');
  if (ni < pi) target.classList.add('slide-back');
  lastView = name;
  qsa('.navbtn').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  ({ home:renderHome, cards:renderCards, market:renderMarket, games:renderGames,
     chat:renderChat, profile:renderProfile, admin:renderAdmin })[name]?.();
}

/* ─ View-level error helper ─────────────────────────────────── */
function viewError(container, msg, retryFn) {
  container.innerHTML = `
    <div style="text-align:center;padding:40px 20px">
      <div style="font-size:36px;margin-bottom:12px">⚠️</div>
      <p style="color:var(--rose);font-size:13px;margin-bottom:16px">${esc(msg)}</p>
      ${retryFn ? `<button class="cta" onclick="(${retryFn.toString()})()">🔄 Qayta urinish</button>` : ''}
    </div>`;
}

/* ═══════════════════════════════════════════════════════════════
   HOME
═══════════════════════════════════════════════════════════════ */
async function renderHome() {
  /* Daily chest */
  const claimed = ME.chest_claimed_at &&
    new Date(ME.chest_claimed_at).toDateString() === new Date().toDateString();
  $('dailyChestBanner').classList.toggle('claimed', !!claimed);
  $('dailyChestBanner').onclick = () => openChest();

  /* Daily bonus dot */
  const dailyOk = !ME.daily_claimed_at ||
    new Date(ME.daily_claimed_at).toDateString() !== new Date().toDateString();
  $('dailyDot').style.display = dailyOk ? '' : 'none';

  /* Top cards */
  const topGrid = $('topCards');
  topGrid.innerHTML = skeletonGrid(6);
  try {
    if (!allCards.length) allCards = await api('/cards');
    renderCardGrid(topGrid, allCards.slice(0, 6), { small: true });
  } catch (e) {
    viewError(topGrid, e.message, renderHome);
  }

  /* Featured drop */
  try {
    const drops = await api('/market/featured');
    if (drops.length) {
      const d = drops[0];
      $('featuredBanner').hidden = false;
      $('fName').textContent = d.card_name || 'Maxsus karta';
      const diff = Math.max(0, new Date(d.ends_at) - Date.now());
      const h = Math.floor(diff / 3600000), m = Math.floor((diff % 3600000) / 60000);
      $('fCountdown').textContent = `⏳ ${h}s ${m}daq qoldi`;
    } else {
      $('featuredBanner').hidden = true;
    }
  } catch (_) { $('featuredBanner').hidden = true; }

  /* Jackpot pool */
  try {
    const jp = await api('/games/jackpot');
    $('jackpotPool').textContent = fmt(jp.pool_ball) + ' 🪙';
  } catch (_) { $('jackpotPool').textContent = '—'; }

  /* Leaderboard */
  try {
    const users = await api('/admin/users?limit=5');
    const list  = $('rankList');
    list.innerHTML = '';
    users.slice(0, 5).forEach((u, i) => {
      list.appendChild(el('li','',`<b>${i+1}</b><span>${esc(u.name)}</span><small>${fmt(u.achko)} ⚔️</small>`));
    });
  } catch (_) { $('rankList').innerHTML = '<li><b>—</b><span style="color:var(--dim)">Reyting yuklanmadi</span></li>'; }

  renderMissions();
}

/* ── Skeleton helpers ───────────────────────────────────────── */
function skeletonGrid(n) {
  return Array(n).fill(`<div class="skeleton-tile">
    <div class="skeleton-art"><div class="skeleton-line"></div></div>
    <div class="skeleton-body"><div class="skeleton-line"></div><div class="skeleton-line short"></div></div>
  </div>`).join('');
}

function renderMissions() {
  const defs = [
    { id:'m_play3',  text:"3 ta o'yin o'ynash",              reward: 1000 },
    { id:'m_chest1', text:"Sandiq ochish",                    reward: 2000 },
    { id:'m_trade1', text:"Karta sotish yoki sovg'a qilish",  reward: 1500 },
  ];
  const done  = ME.missions_done || [];
  const list  = $('missionList');
  if (!list) return;
  list.innerHTML = '';
  $('missionFill').style.width   = (done.length / defs.length * 100) + '%';
  $('missionCount').textContent  = `${done.length}/${defs.length}`;
  defs.forEach(m => {
    const isDone = done.includes(m.id);
    const li = el('li', isDone ? 'done' : '');
    li.innerHTML = `<span><span class="mcheck">${isDone ? '✓' : ''}</span>${esc(m.text)}</span><b>+${fmt(m.reward)} 🪙</b>`;
    if (!isDone) {
      li.style.cursor = 'pointer';
      li.onclick = async () => {
        try {
          ME = await api(`/users/claim-mission/${m.id}`, 'POST');
          renderTopbar(); renderLevelBar(); renderMissions();
          toast('✅ Vazifa bajarildi! +' + fmt(m.reward) + ' 🪙', 'success');
        } catch (e) { toast('❌ ' + e.message, 'error'); }
      };
    }
    list.appendChild(li);
  });
}

async function handleQuickAction(action) {
  if (action === 'daily') {
    try {
      ME = await api('/users/daily-bonus', 'POST');
      renderTopbar(); renderLevelBar();
      toast('🎁 Kunlik bonus! +2000 🪙 +100 XP', 'success');
      $('dailyDot').style.display = 'none';
    } catch (e) { toast('❌ ' + e.message, 'error'); }
  } else if (action === 'openChest') {
    openChest();
  }
}

/* ═══════════════════════════════════════════════════════════════
   CARDS
═══════════════════════════════════════════════════════════════ */
let cardRarity = 'all';

async function renderCards() {
  const grid = $('allCards');
  grid.innerHTML = skeletonGrid(6);
  try {
    if (!allCards.length) allCards = await api('/cards');
    try { myCards = await api('/cards/mine'); } catch (_) { myCards = []; }
    setupCardTabs();
    applyCardFilter();
    renderMyCardsProfile();
  } catch (e) { viewError(grid, e.message, renderCards); }
}

function setupCardTabs() {
  qsa('#cardTabs .tab').forEach(t => {
    t.onclick = () => {
      qsa('#cardTabs .tab').forEach(x => x.classList.remove('active'));
      t.classList.add('active'); cardRarity = t.dataset.filter; applyCardFilter();
    };
  });
}

function switchCardMode(mode) {
  cardMode = mode;
  $('tabAllCards').classList.toggle('active', mode === 'all');
  $('tabMyCards').classList.toggle('active', mode === 'mine');
  applyCardFilter();
}

function applyCardFilter() {
  let cards = cardMode === 'mine' ? myCards : allCards;
  if (cardRarity !== 'all') cards = cards.filter(c => c.rarity === cardRarity);
  renderCardGrid($('allCards'), cards, { large: true, buyable: cardMode === 'all' });
}

function renderCardGrid(container, cards, opts = {}) {
  if (!container) return;
  container.innerHTML = '';
  if (!cards.length) {
    container.innerHTML = '<p style="color:var(--dim);font-size:12px;text-align:center;grid-column:1/-1;padding:28px">🌸 Kartalar yo\'q</p>';
    return;
  }
  cards.forEach((c, i) => container.appendChild(makeCardTile(c, opts, i)));
}

function makeCardTile(c, opts = {}, idx = 0) {
  const owned = myCards.some(mc => (mc.card_id || mc.id) === c.id);
  const div   = el('div', `cardtile r-${c.rarity}`);
  div.style.animationDelay = Math.min(idx * 50, 400) + 'ms';

  const art = el('div', 'cardart');
  if (c.image_url) {
    art.style.cssText = `background-image:url(${c.image_url});background-size:cover;background-position:center`;
  } else {
    art.innerHTML = `<span>${RARITY_EMOJI[c.rarity] || '🌸'}</span>`;
  }
  const rtag = el('span', 'rarity-tag', c.rarity);
  rtag.style.color = RARITY_CLR[c.rarity] || '#fff';
  art.appendChild(rtag);
  if (c.is_limited) art.innerHTML += '<span class="limited-badge">⏳ LIMITED</span>';
  div.appendChild(art);

  const body = el('div', 'cardbody');
  body.innerHTML = `<b title="${esc(c.name)}">${esc(c.name)}</b>
    <div class="cardprice">🪙 ${fmt(c.base_price_ball)}</div>`;

  if (opts.buyable) {
    const btn = el('button', 'buybtn', owned ? '✓ Mavjud' : '🛒 Sotib ol');
    if (owned) btn.style.background = 'var(--green)';
    else btn.onclick = e => { e.stopPropagation(); buyCard(c); };
    body.appendChild(btn);
  } else if (cardMode === 'mine') {
    const btn = el('button', 'buybtn', '🏪 Sotish');
    btn.style.background = 'var(--grad-cyan)';
    btn.onclick = e => { e.stopPropagation(); promptListCard(c); };
    body.appendChild(btn);
  }
  div.appendChild(body);
  div.addEventListener('click', () => showCardModal(c));
  return div;
}

async function buyCard(card) {
  try {
    const res = await api(`/market/shop/buy/${card.id}`, 'POST');
    ME = res.user;
    myCards  = await api('/cards/mine');
    allCards = await api('/cards');
    renderTopbar(); renderLevelBar(); applyCardFilter();
    showCardEvent('bought', card);
  } catch (e) { toast('❌ ' + e.message, 'error'); }
}

function showCardModal(card) {
  const overlay = $('cardModal');
  overlay.hidden = false; overlay.innerHTML = '';
  const sheet = el('div', 'cardmodal-sheet');
  const art = el('div', `cardmodal-art r-${card.rarity}`);
  if (card.image_url) {
    art.style.cssText = `background-image:url(${card.image_url});background-size:cover;background-position:center`;
  } else {
    art.innerHTML = `<span style="font-size:70px">${RARITY_EMOJI[card.rarity] || '🌸'}</span>`;
  }
  sheet.appendChild(art);
  sheet.innerHTML += `
    <h2 class="cardmodal-name">${esc(card.name)}</h2>
    <span class="cardmodal-anime">${esc(card.anime || '')}</span>
    <span class="cardmodal-rarity" style="color:${RARITY_CLR[card.rarity]}">${card.rarity}</span>
    <div class="cardmodal-row"><span>🪙 Ball narx</span><b>${fmt(card.base_price_ball)}</b></div>
    <div class="cardmodal-row"><span>💎 Diamond</span><b>${fmt(card.base_price_diamond)}</b></div>
    <div class="cardmodal-row"><span>📦 Kod</span><b>${esc(card.code || '—')}</b></div>
    <div class="cardmodal-row"><span>🔄 Sotiladi</span><b>${card.sellable ? '✅' : '❌'}</b></div>`;

  const owned = myCards.some(mc => (mc.card_id || mc.id) === card.id);
  const acts  = el('div', 'cardmodal-actions');

  if (!owned) {
    const buy = el('button', 'cta', `🛒 Sotib olish · 🪙${fmt(card.base_price_ball)}`);
    buy.onclick = () => { overlay.hidden = true; buyCard(card); };
    acts.appendChild(buy);
  } else {
    const sell = el('button', 'cta', '🏪 Marketga qo\'yish');
    sell.style.background = 'var(--grad-cyan)';
    sell.onclick = () => { overlay.hidden = true; promptListCard(card); };
    acts.appendChild(sell);
    const gift = el('button', 'cta', '🎁 Sovg\'a qilish');
    gift.style.background = 'linear-gradient(135deg,#5b69ff,#9b59f5)';
    gift.onclick = () => { overlay.hidden = true; promptGiftCard(card); };
    acts.appendChild(gift);
  }
  const close = el('button', 'cardmodal-close', '✕');
  close.onclick = () => overlay.hidden = true;
  sheet.append(acts, close);
  overlay.appendChild(sheet);
  overlay.onclick = e => { if (e.target === overlay) overlay.hidden = true; };
}

async function promptListCard(card) {
  const owned = myCards.find(mc => (mc.card_id || mc.id) === card.id);
  if (!owned) return;
  const price = prompt(`"${card.name}" kartasini necha 🪙 ga?\nAI tavsiya: ~${Math.round(card.base_price_ball * 1.2)}`);
  if (!price || isNaN(price)) return;
  try {
    await api('/market/list', 'POST', { ownership_id: owned.ownership_id || owned.id, price_ball: parseInt(price) });
    toast('✅ Karta marketga qo\'yildi!', 'success');
    myCards = await api('/cards/mine');
  } catch (e) { toast('❌ ' + e.message, 'error'); }
}

async function promptGiftCard(card) {
  const owned = myCards.find(mc => (mc.card_id || mc.id) === card.id);
  if (!owned) return;
  const tgId = prompt('Qabul qiluvchining Telegram ID:');
  if (!tgId || isNaN(tgId)) return;
  try {
    await api('/market/gift', 'POST', { ownership_id: owned.ownership_id || owned.id, recipient_telegram_id: parseInt(tgId) });
    showCardEvent('gifted', card);
    myCards = await api('/cards/mine');
    applyCardFilter();
  } catch (e) { toast('❌ ' + e.message, 'error'); }
}

function renderMyCardsProfile() {
  renderCardGrid($('myCardsGrid'), myCards.slice(0, 6), { small: true });
}

/* ═══════════════════════════════════════════════════════════════
   MARKET
═══════════════════════════════════════════════════════════════ */
let mTab = 'shop';

async function renderMarket() {
  setupMarketTabs();
  loadMTab(mTab);
}

function setupMarketTabs() {
  qsa('#marketTabs .tab').forEach(t => {
    t.onclick = () => {
      qsa('#marketTabs .tab').forEach(x => x.classList.remove('active'));
      t.classList.add('active'); mTab = t.dataset.mtab; loadMTab(mTab);
    };
  });
}

const noItems = t => `<p style="color:var(--dim);text-align:center;padding:28px;font-size:12px">🌸 ${t||'Bo\'sh'}</p>`;

async function loadMTab(tab) {
  const list = $('marketList');
  list.innerHTML = '<p style="color:var(--dim);text-align:center;padding:24px">⏳ Yuklanmoqda...</p>';
  try {
    if (tab === 'shop') {
      const items = await api('/cards');
      list.innerHTML = '';
      if (!items.length) { list.innerHTML = noItems('Do\'kon bo\'sh'); return; }
      items.forEach((c, i) => list.appendChild(makeShopRow(c, i)));

    } else if (tab === 'listings') {
      const items = await api('/market/listings');
      list.innerHTML = '';
      if (!items.length) { list.innerHTML = noItems('Faol e\'lonlar yo\'q'); return; }
      items.forEach((l, i) => list.appendChild(makeListingRow(l, i)));

    } else if (tab === 'featured') {
      const items = await api('/market/featured');
      list.innerHTML = '';
      if (!items.length) { list.innerHTML = noItems('Featured drop yo\'q'); return; }
      items.forEach((d, i) => {
        const row = el('div','listrow'); row.style.animationDelay = i*40+'ms';
        const thumb = el('div','listrow-thumb'); thumb.textContent = '⭐';
        const info  = el('div','listrow-info',`<b>${esc(d.card_name||'Karta')}</b><small>Tugaydi: ${new Date(d.ends_at).toLocaleString('uz')}</small>`);
        const btn   = el('button','listrow-actbtn','👀 Ko\'rish');
        btn.onclick = () => { const c = allCards.find(x => x.id === d.card_template_id); if (c) showCardModal(c); };
        row.append(thumb, info, btn); list.appendChild(row);
      });

    } else if (tab === 'mine') {
      const items = await api('/market/my-listings');
      list.innerHTML = '';
      if (!items.length) { list.innerHTML = noItems('Sizning e\'lonlaringiz yo\'q'); return; }
      items.forEach((l, i) => list.appendChild(makeMyListRow(l, i)));
    }
  } catch (e) {
    list.innerHTML = `<div style="text-align:center;padding:28px">
      <p style="color:var(--rose);margin-bottom:12px">❌ ${esc(e.message)}</p>
      <button class="cta" onclick="loadMTab('${tab}')">🔄 Qayta urinish</button></div>`;
  }
}

function thumbEl(card) {
  const t = el('div',`listrow-thumb r-${card?.rarity||''}`);
  if (card?.image_url) t.style.cssText=`background-image:url(${card.image_url});background-size:cover;background-position:center`;
  else t.textContent = RARITY_EMOJI[card?.rarity] || '🌸';
  return t;
}

function makeShopRow(c, i) {
  const owned = myCards.some(mc => (mc.card_id||mc.id) === c.id);
  const row = el('div','listrow'); row.style.animationDelay = i*40+'ms';
  const info = el('div','listrow-info',`<b>${esc(c.name)}</b><small style="color:${RARITY_CLR[c.rarity]}">${c.rarity}</small>`);
  const price = el('span','listrow-price',`🪙 ${fmt(c.base_price_ball)}`);
  const btn = el('button','listrow-actbtn', owned ? '✓ Mavjud' : '🛒 Olish');
  if (owned) btn.style.background = 'var(--green)';
  else btn.onclick = () => buyCard(c);
  row.onclick = () => showCardModal(c);
  row.append(thumbEl(c), info, price, btn);
  return row;
}

function makeListingRow(l, i) {
  const row = el('div','listrow'); row.style.animationDelay = i*40+'ms';
  const info = el('div','listrow-info',`<b>${esc(l.card?.name||'—')}</b><small>Sotuvchi: ${esc(l.seller_name||'?')} • AI: 🪙${fmt(l.ai_suggested_price||0)}</small>`);
  const price = el('span','listrow-price',`🪙 ${fmt(l.price_ball)}`);
  const btn = el('button','listrow-actbtn','💰 Olish');
  btn.onclick = async () => {
    try {
      const res = await api(`/market/buy/${l.id}`, 'POST');
      ME = res.user; renderTopbar(); renderLevelBar();
      showCardEvent('bought', l.card); loadMTab(mTab);
    } catch (e) { toast('❌ ' + e.message, 'error'); }
  };
  row.append(thumbEl(l.card), info, price, btn);
  return row;
}

function makeMyListRow(l, i) {
  const row = el('div','listrow'); row.style.animationDelay = i*40+'ms';
  const info = el('div','listrow-info',`<b>${esc(l.card?.name||'—')}</b><small>Mening e'lonim</small>`);
  const price = el('span','listrow-price',`🪙 ${fmt(l.price_ball)}`);
  const btn = el('button','listrow-actbtn sell','❌ Bekor');
  btn.onclick = async () => {
    try { await api(`/market/cancel/${l.id}`, 'POST'); toast('✅ E\'lon bekor qilindi','success'); loadMTab(mTab); }
    catch (e) { toast('❌ ' + e.message, 'error'); }
  };
  row.append(thumbEl(l.card), info, price, btn);
  return row;
}

/* ═══════════════════════════════════════════════════════════════
   GAMES
═══════════════════════════════════════════════════════════════ */
const GAMES = {
  wheel:   { name:'🎡 Omad g\'ildiragi', desc:'Aylanib omad sinab ko\'ring',  cost:500  },
  jackpot: { name:'🎰 Jackpot Slot',     desc:'Uchta bir xil belgini top',    cost:250  },
  mini:    { name:'🎯 Nishon o\'yini',   desc:'Nishonga teg va yut',          cost:300  },
  memory:  { name:'🧠 Xotira',           desc:'Juft kartalarni top',          cost:400  },
  guess:   { name:'🔢 Son topish',       desc:'1-100 orasidagi sonni top',    cost:200  },
  reflex:  { name:'⚡ Refleks',          desc:'Signalga tez reaksiya qil',    cost:350  },
};

async function renderGames() {
  const grid = $('gameGrid'); grid.innerHTML = '';
  try { $('jackpotPoolDisplay').textContent = fmt((await api('/games/jackpot')).pool_ball) + ' 🪙'; } catch (_) {}
  if (ME.freeze_until && new Date(ME.freeze_until) > new Date()) {
    $('freezeNote').hidden = false;
    $('freezeNote').textContent = '⏳ ' + Math.ceil((new Date(ME.freeze_until)-Date.now())/60000) + ' daqiqa muzlatilgan';
  } else { $('freezeNote').hidden = true; }

  Object.entries(GAMES).forEach(([key, g], i) => {
    const t = el('div','gametile'); t.style.animationDelay = i*55+'ms';
    t.innerHTML = `<span>${g.name.split(' ')[0]}</span><b>${g.name.slice(2)}</b><small>${g.desc}</small><small style="color:var(--gold)">Narx: ${fmt(g.cost)} 🪙</small>`;
    const btn = el('button','gobtn','▶ O\'ynash'); btn.onclick = () => openGame(key);
    t.appendChild(btn); grid.appendChild(t);
  });
  const ct = el('div','gametile');
  ct.style.cssText = 'background:linear-gradient(160deg,#241a3a,#150e2e);border-color:rgba(255,200,87,.35)';
  ct.innerHTML = `<span>🧰</span><b>Sandiq</b><small>Noyob kartalar oling</small><small style="color:var(--gold)">1 🔑 kalit kerak</small>`;
  const cb = el('button','gobtn','🔑 Ochish'); cb.style.cssText='background:var(--grad-gold);color:#2a1500';
  cb.onclick = openChest; ct.appendChild(cb); grid.appendChild(ct);
}

function openGame(key) {
  const m = $('gameModal'); m.hidden=false; m.classList.remove('show');
  $('gmodal-result').hidden=true; $('gmodal-close').hidden=true;
  requestAnimationFrame(() => m.classList.add('show'));
  $('gmodalBackdrop').onclick = closeGame; $('gmodal-close').onclick = closeGame;
  $('gmodal-title').textContent = GAMES[key].name;
  const body = $('gmodal-body'); body.innerHTML = '';
  ({ wheel:buildWheel, jackpot:buildJackpot, mini:buildMini,
     memory:buildMemory, guess:buildGuess, reflex:buildReflex })[key]?.(body, key);
}

function closeGame() { const m=$('gameModal'); m.classList.remove('show'); setTimeout(()=>m.hidden=true,400); }

function showGameResult(win, data = {}) {
  const res=$('gmodal-result'); res.hidden=false; $('gmodal-close').hidden=false;
  res.innerHTML=`<div class="gres-icon gres-anim">${win?(data.jackpot?'🎰':'🏆'):'😔'}</div>
    <div class="gres-title ${win?'gres-win':'gres-lose'}">${win?(data.jackpot?'JACKPOT!':'G\'ALABA!'):'Yutqazdingiz'}</div>
    <div class="gres-sub">${win?`+${fmt(data.reward_ball||0)} 🪙 oldi!`:'Omad keyingi safar!'}</div>`;
  api('/users/me').then(u => { ME=u; renderTopbar(); renderLevelBar(); }).catch(()=>{});
}

/* ─ Wheel ─────────────────────────────────────────────────── */
const WSEGS=[{w:40,ball:50,label:'50🪙',color:'#4a3770'},{w:25,ball:150,label:'150🪙',color:'#5b3d8a'},
  {w:15,ball:300,label:'300🪙',color:'#7a2bf5'},{w:10,ball:700,label:'700🪙',color:'#c04dff'},
  {w:7,ball:1500,label:'1500🪙',color:'#ffc857'},{w:3,ball:5000,label:'JACKPOT',color:'#ff5c92'}];

function buildWheel(body,key){
  const wrap=el('div','wheel-wrap'); wrap.innerHTML='<div class="wheel-pointer">▼</div>';
  const cv=document.createElement('canvas'); cv.id='wheelCanvas'; cv.width=cv.height=260;
  wrap.appendChild(cv);
  wrap.innerHTML+=`<p class="wheel-hint">Narx: ${fmt(GAMES[key].cost)} 🪙</p>`;
  const btn=el('button','cta','🎡 Aylantirish'); btn.style.width='100%';
  wrap.appendChild(btn); body.appendChild(wrap); drawWheel(cv); let busy=false;
  btn.onclick=async()=>{
    if(busy)return; busy=true; btn.disabled=true;
    try{
      const r=await api(`/games/play/${key}`,'POST');
      let idx=WSEGS.findIndex(s=>s.ball>=r.reward_ball); if(idx<0)idx=5;
      spinWheel(cv,idx,()=>showGameResult(r.win,r));
    }catch(e){toast('❌ '+e.message,'error');busy=false;btn.disabled=false;}
  };
}
function drawWheel(cv){
  const ctx=cv.getContext('2d'),cx=cv.width/2,r=cx-4;
  const total=WSEGS.reduce((a,s)=>a+s.w,0); let a=-Math.PI/2;
  ctx.clearRect(0,0,cv.width,cv.height);
  WSEGS.forEach(s=>{const span=(s.w/total)*Math.PI*2;ctx.beginPath();ctx.moveTo(cx,cx);ctx.arc(cx,cx,r,a,a+span);ctx.closePath();ctx.fillStyle=s.color;ctx.fill();ctx.strokeStyle='rgba(255,255,255,.1)';ctx.lineWidth=2;ctx.stroke();ctx.save();ctx.translate(cx,cx);ctx.rotate(a+span/2);ctx.textAlign='right';ctx.fillStyle='#fff';ctx.font='bold 10px Manrope,sans-serif';ctx.shadowColor='rgba(0,0,0,.6)';ctx.shadowBlur=4;ctx.fillText(s.label,r-8,4);ctx.restore();a+=span;});
  ctx.beginPath();ctx.arc(cx,cx,16,0,Math.PI*2);ctx.fillStyle='#12093a';ctx.fill();ctx.strokeStyle='rgba(255,255,255,.25)';ctx.lineWidth=2;ctx.stroke();
}
function spinWheel(cv,ti,cb){
  const total=WSEGS.reduce((a,s)=>a+s.w,0);let cum=0;for(let i=0;i<ti;i++)cum+=(WSEGS[i].w/total)*Math.PI*2;cum+=(WSEGS[ti].w/total)*Math.PI*2/2;
  const target=(5+Math.random()*3)*Math.PI*2+(Math.PI*2-cum),t0=performance.now(),dur=3600;
  const ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;drawWheel(cv);
  (function fr(now){const t=Math.min((now-t0)/dur,1);cv.style.transform=`rotate(${ease(t)*target}rad)`;if(t<1)requestAnimationFrame(fr);else setTimeout(cb,350);})(performance.now());
}

/* ─ Jackpot ────────────────────────────────────────────────── */
const SYMS=['🍒','🍋','🔔','⭐','💎','🎰'];
function buildJackpot(body,key){
  const wrap=el('div','slot-machine');
  wrap.innerHTML=`<div class="slot-title">JACKPOT SLOT</div><div class="slot-lights">${Array(7).fill('<div class="slot-light"></div>').join('')}</div><div class="slot-reels"><div class="slot-reel"><span class="slot-sym" id="r0">🎰</span></div><div class="slot-reel"><span class="slot-sym" id="r1">🎰</span></div><div class="slot-reel"><span class="slot-sym" id="r2">🎰</span></div></div><div class="slot-lights">${Array(7).fill('<div class="slot-light"></div>').join('')}</div><p style="color:var(--dim);font-size:11px">Narx: ${fmt(GAMES[key].cost)} 🪙</p>`;
  const btn=el('button','cta','🎰 O\'ynash');btn.style.width='100%';wrap.appendChild(btn);body.appendChild(wrap);let busy=false;
  btn.onclick=async()=>{if(busy)return;busy=true;btn.disabled=true;
    const ivs=[0,1,2].map(i=>setInterval(()=>{const s=$(`r${i}`);if(s)s.textContent=SYMS[Math.floor(Math.random()*SYMS.length)];},90));
    try{const r=await api(`/games/play/${key}`,'POST');setTimeout(()=>{ivs.forEach(clearInterval);const reels=r.reels||['🍒','🍋','🔔'];[0,1,2].forEach(i=>setTimeout(()=>{const s=$(`r${i}`);if(s){s.textContent=reels[i];s.classList.remove('spinning');s.classList.add('stop');}},i*260));setTimeout(()=>{if(r.jackpot)$('gameModal').classList.add('jackpot-flash');showGameResult(r.win||r.jackpot,r);busy=false;},1100);},1800);}
    catch(e){ivs.forEach(clearInterval);toast('❌ '+e.message,'error');busy=false;btn.disabled=false;}
  };
}

/* ─ Mini ───────────────────────────────────────────────────── */
function buildMini(body,key){let score=0,time=15,playing=false,tmo;const wrap=el('div','mini-wrap');wrap.innerHTML=`<div class="mini-arena" id="miniArena"><div class="mini-countdown" id="mTimer">15</div><div class="mini-score" id="mScore">0</div><div class="mini-timer-bar" id="mBar" style="width:100%"></div></div><p class="mini-hint">Nishonga teging! Narx: ${fmt(GAMES[key].cost)} 🪙</p>`;const btn=el('button','cta','▶ Boshlash');btn.style.width='100%';wrap.appendChild(btn);body.appendChild(wrap);const emjs=['🌸','⭐','💎','🎯','🔮','💫'];function spawn(){qsa('.mini-target').forEach(t=>t.remove());const arena=$('miniArena');if(!arena)return;const t=el('div','mini-target',emjs[Math.floor(Math.random()*emjs.length)]);t.style.left=Math.random()*(arena.offsetWidth-60)+'px';t.style.top=Math.random()*(arena.offsetHeight-65)+'px';t.onclick=()=>{score++;$('mScore').textContent=score+' ta';spawn();};arena.appendChild(t);tmo=setTimeout(spawn,1700);}
btn.onclick=()=>{if(playing)return;playing=true;btn.remove();spawn();const iv=setInterval(()=>{time--;const mT=$('mTimer'),mB=$('mBar');if(mT)mT.textContent=time;if(mB)mB.style.width=(time/15*100)+'%';if(time<=0){clearInterval(iv);clearTimeout(tmo);qsa('.mini-target').forEach(t=>t.remove());api(`/games/play/${key}`,'POST').then(r=>showGameResult(r.win,r)).catch(e=>toast('❌ '+e.message,'error'));}},1000);};}

/* ─ Memory ─────────────────────────────────────────────────── */
function buildMemory(body,key){const emjs=['🌸','⭐','💎','🔮','💫','🎯'];const pairs=[...emjs,...emjs].sort(()=>Math.random()-.5);let flipped=[],matched=0,tries=0,busy=false;const wrap=el('div','memory-wrap');wrap.innerHTML=`<div class="memory-info"><span>Topilgan: <b id="memM">0</b>/${emjs.length}</span><span>Urinishlar: <b id="memT">0</b></span></div>`;const grid=el('div','memory-grid');pairs.forEach(e=>{const c=el('div','mem-card');c.innerHTML=`<div class="mem-inner"><div class="mem-front">?</div><div class="mem-back">${e}</div></div>`;c.dataset.e=e;c.onclick=()=>{if(busy||flipped.length>=2||c.classList.contains('mem-flip')||c.classList.contains('mem-matched'))return;c.classList.add('mem-flip');flipped.push(c);if(flipped.length===2){tries++;$('memT').textContent=tries;busy=true;setTimeout(()=>{if(flipped[0].dataset.e===flipped[1].dataset.e){flipped.forEach(x=>x.classList.add('mem-matched'));matched++;$('memM').textContent=matched;if(matched===emjs.length)api(`/games/play/${key}`,'POST').then(r=>showGameResult(r.win,r)).catch(e=>toast('❌ '+e.message,'error'));}else{flipped.forEach(x=>x.classList.remove('mem-flip'));}flipped=[];busy=false;},900);}};grid.appendChild(c);});wrap.appendChild(grid);const skip=el('button','cta','⏩ Tezkor natija');skip.style.cssText='width:100%;margin-top:10px';skip.onclick=()=>api(`/games/play/${key}`,'POST').then(r=>showGameResult(r.win,r)).catch(e=>toast('❌ '+e.message,'error'));wrap.appendChild(skip);body.appendChild(wrap);}

/* ─ Guess ──────────────────────────────────────────────────── */
function buildGuess(body,key){let tries=0,max=5,secret=Math.ceil(Math.random()*100);const wrap=el('div','guess-wrap');wrap.innerHTML=`<div class="guess-title">1 dan 100 gacha sonni top</div><div class="guess-tries-left" id="gLeft">${max} ta urinish</div><div class="guess-hint" id="gHint">Sonni kiriting</div><div class="guess-input-row"><input type="number" class="guess-input" id="gInput" min="1" max="100" placeholder="1–100"><button class="cta" id="gBtn">✓</button></div><div class="guess-history" id="gHist"></div>`;body.appendChild(wrap);function check(){const v=parseInt($('gInput').value);if(!v||v<1||v>100){toast('1-100 orasida son kiriting','error');return;}if(tries>=max)return;tries++;$('gLeft').textContent=`${max-tries} ta urinish qoldi`;let hint='',color='var(--dim)';if(v===secret){hint='✅ To\'g\'ri!';color='var(--green)';}else if(Math.abs(v-secret)<=5){hint='🔥 Juda issiq!';color='#ff9f4a';}else if(Math.abs(v-secret)<=15){hint='♨️ Issiq';color='var(--gold)';}else{hint=v<secret?'⬆️ Kattaroq':'⬇️ Kichikroq';color='var(--cyan)';}const row=el('div','guess-hist-row',`<b>${v}</b><small style="color:${color}">${hint}</small>`);$('gHist').prepend(row);$('gHint').textContent=hint;$('gHint').style.color=color;$('gInput').value='';if(v===secret||tries>=max){$('gBtn').disabled=true;$('gInput').disabled=true;api(`/games/play/${key}`,'POST').then(r=>{r.win=(v===secret);showGameResult(r.win,r);}).catch(e=>toast('❌ '+e.message,'error'));if(tries>=max&&v!==secret)$('gHint').textContent=`Javob: ${secret}`;}}$('gBtn').onclick=check;}

/* ─ Reflex ─────────────────────────────────────────────────── */
function buildReflex(body,key){let state='wait',t0,started=false;const wrap=el('div','reflex-wrap');wrap.innerHTML=`<div class="reflex-instruction" id="rInst">Tayyor bo'ling...</div><div class="reflex-arena" id="rArena"><div class="reflex-target" id="rTarget" style="opacity:0">⚡</div></div><p class="reflex-hint">Signal chiqqanda TEZDA bosing! Narx: ${fmt(GAMES[key].cost)} 🪙</p>`;const btn=el('button','cta','▶ Boshlash');btn.style.width='100%';wrap.appendChild(btn);body.appendChild(wrap);btn.onclick=()=>{if(started)return;started=true;btn.remove();$('rInst').textContent='Kutib turing...';setTimeout(()=>{state='ready';t0=Date.now();$('rTarget').style.opacity='1';$('rArena').classList.add('ready');$('rInst').textContent='🔴 HOZIR BOSING!';},1500+Math.random()*3000);};$('rArena').onclick=()=>{if(state!=='ready')return;const ms=Date.now()-t0;state='done';$('rTarget').style.opacity='0';$('rArena').classList.remove('ready');$('rInst').textContent=`Reaksiya: ${ms}ms ${ms<300?'⚡ Ajoyib!':ms<500?'👍 Yaxshi':'😐 Sekin'}`;api(`/games/play/${key}`,'POST').then(r=>showGameResult(r.win,r)).catch(e=>toast('❌ '+e.message,'error'));};}

/* ═══════════════════════════════════════════════════════════════
   CHEST
═══════════════════════════════════════════════════════════════ */
function openChest(){
  const m=$('gameModal');m.hidden=false;m.classList.remove('show');$('gmodal-result').hidden=true;$('gmodal-close').hidden=true;
  requestAnimationFrame(()=>m.classList.add('show'));$('gmodalBackdrop').onclick=closeGame;$('gmodal-close').onclick=closeGame;$('gmodal-title').textContent='🧰 Sandiq Ochish';
  const body=$('gmodal-body');body.innerHTML='';const wrap=el('div','chest-wrap');const emoji=el('div','chest-emoji','🧰');
  const hint=el('p','chest-hint',`Sandiqni bosing!\nKalit: ${ME.keys||0} ta 🔑`);const parts=el('div','chest-particles');
  wrap.append(emoji,hint,parts);body.appendChild(wrap);let opened=false;
  emoji.onclick=async()=>{if(opened)return;emoji.classList.add('shake');setTimeout(async()=>{emoji.classList.remove('shake');if(opened)return;opened=true;
    try{const r=await api('/chest/open','POST');emoji.classList.add('open');
      const ps=['⭐','💎','🌸','✨','💫','🎊','🌟','🎴'];for(let i=0;i<10;i++){const p=el('span','particle',ps[i%ps.length]);const a=Math.random()*Math.PI*2,d=60+Math.random()*90;p.style.cssText=`--tx:${Math.cos(a)*d}px;--ty:${Math.sin(a)*d}px;animation-delay:${i*55}ms`;parts.appendChild(p);}
      setTimeout(()=>{closeGame();ME=r.user;renderTopbar();renderLevelBar();showCardEvent('added',r.won_card);},700);
    }catch(e){opened=false;toast('❌ '+e.message,'error');closeGame();}},480);};
}

/* ═══════════════════════════════════════════════════════════════
   CHAT
═══════════════════════════════════════════════════════════════ */
async function renderChat(){
  setupChatTabs(); connectWS(wsRoom); loadChatHistory(wsRoom);
  $('chatForm').onsubmit=e=>{e.preventDefault();const inp=$('chatInput'),text=inp.value.trim();if(!text)return;if(WS?.readyState===1){WS.send(JSON.stringify({text}));inp.value='';}else toast('Chat ulanmagan','error');};
}
function setupChatTabs(){qsa('#chatRoomTabs .tab').forEach(t=>{t.onclick=()=>{qsa('#chatRoomTabs .tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');wsRoom=t.dataset.room;connectWS(wsRoom);loadChatHistory(wsRoom);};});}
async function loadChatHistory(room){const box=$('chatBox');box.innerHTML='';try{const msgs=await api(`/chat/history?room=${room}&limit=60`);msgs.forEach(m=>appendMsg(m));box.scrollTop=box.scrollHeight;}catch(_){}}
function connectWS(room){if(WS){WS.close();WS=null;}if(!initData)return;const wsUrl=BASE.replace('https','wss').replace('http','ws').replace('/api','');try{WS=new WebSocket(`${wsUrl}/ws/chat?init_data=${encodeURIComponent(initData)}&room=${room}`);WS.onmessage=e=>{try{appendMsg(JSON.parse(e.data));}catch(_){}};WS.onerror=()=>{};WS.onclose=()=>setTimeout(()=>{if(wsRoom===room)connectWS(room);},3000);}catch(_){}}
function appendMsg(m){const box=$('chatBox');if(!box)return;const isMe=ME&&m.user_id===ME.id;const row=el('div',`chatmsg-row${isMe?' mine':''}`);if(!isMe){const av=el('div','chatavatar',(m.user_name||'?')[0].toUpperCase());if(m.avatar_url){av.style.cssText=`background-image:url(${m.avatar_url});background-size:cover;background-position:center`;av.textContent='';}row.appendChild(av);}const msg=el('div',`chatmsg${isMe?' mine':''}`);msg.innerHTML=`<b>${esc(m.user_name||'?')} <em class="chatrank">${esc(m.rank_title||'')}</em></b>${esc(m.text)}`;row.appendChild(msg);box.appendChild(row);box.scrollTop=box.scrollHeight;}

/* ═══════════════════════════════════════════════════════════════
   PROFILE
═══════════════════════════════════════════════════════════════ */
async function renderProfile(){
  if(!ME)return;
  const av=$('profileAvatar');
  if(ME.avatar_url){av.style.cssText=`background-image:url(${ME.avatar_url});background-size:cover;background-position:center`;av.textContent='';}
  else{av.style.cssText='';av.textContent=(ME.name||'?')[0].toUpperCase();}
  $('profileName').textContent=ME.name||'—';$('profileId').textContent=`ID: ${ME.telegram_id||ME.id||'—'}`;
  $('profileStatus').textContent=ME.rank_title||'Newbie';$('profileLevel').textContent=`Lv. ${ME.level}`;
  $('profileVip').hidden=!ME.vip;$('statDiamond').textContent=fmt(ME.diamond);$('statBall').textContent=fmt(ME.ball);
  $('statKeys').textContent=ME.keys||0;$('statCards').textContent=myCards.length||0;
  $('statAchko').textContent=fmt(ME.achko);$('statRank').textContent=ME.rank_title||'—';
  $('profLvNum').textContent=ME.level;$('profLvNext').textContent=ME.level+1;
  const pct=Math.min(100,(ME.xp/(ME.xp_next||1))*100);
  $('profXpFill').style.width=pct+'%';$('profXpText').textContent=`${fmt(ME.xp)} / ${fmt(ME.xp_next)} XP`;
  $('nameInput').value=ME.name||'';$('toggleNotifications').checked=ME.notifications_enabled!==false;

  $('avatarFile').onchange=async(e)=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=async(ev)=>{try{ME=await api('/users/me','PUT',{avatar_url:ev.target.result});renderTopbar();renderProfile();toast('✅ Avatar yangilandi','success');}catch(err){toast('❌ '+err.message,'error');}};r.readAsDataURL(f);};
  $('btnSaveName').onclick=async()=>{const n=$('nameInput').value.trim();if(!n)return;try{ME=await api('/users/me','PUT',{name:n});renderTopbar();toast('✅ Ism saqlandi','success');}catch(e){toast('❌ '+e.message,'error');}};
  $('toggleNotifications').onchange=async(e)=>{try{await api('/users/me','PUT',{notifications_enabled:e.target.checked});}catch(err){toast('❌ '+err.message,'error');}};
  $('btnSettings').onclick=()=>{$('settingsPanel').hidden=!$('settingsPanel').hidden;};
  $('btnLogout').onclick=()=>{if(confirm('Chiqishni xohlaysizmi?'))window.Telegram?.WebApp?.close?.();};

  try{myCards=await api('/cards/mine');}catch(_){myCards=[];}
  renderMyCardsProfile();
}

/* ═══════════════════════════════════════════════════════════════
   ADMIN
═══════════════════════════════════════════════════════════════ */
let aTab='dashboard';
async function renderAdmin(){
  if(!ME?.is_admin){toast('❌ Admin huquqi yo\'q','error');navTo('home');return;}
  setupAdminTabs(); loadATab(aTab);
}
function setupAdminTabs(){qsa('#adminTabs .tab').forEach(t=>{t.onclick=()=>{qsa('#adminTabs .tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');aTab=t.dataset.atab;loadATab(aTab);};});}

async function loadATab(tab){
  const c=$('adminContent');c.innerHTML='<p style="color:var(--dim);text-align:center;padding:24px">⏳ Yuklanmoqda...</p>';
  if(tab==='dashboard')await aTabDash(c);
  else if(tab==='users')await aTabUsers(c);
  else if(tab==='cards')await aTabCards(c);
  else if(tab==='ai')await aTabAI(c);
  else if(tab==='drops')await aTabDrops(c);
}

async function aTabDash(c){try{const s=await api('/admin/dashboard');c.innerHTML=`<div class="admin-stats"><div class="astat"><span>👤</span><b>${fmt(s.total_users)}</b><small>Foydalanuvchilar</small></div><div class="astat"><span>🃏</span><b>${fmt(s.total_cards)}</b><small>Kartalar</small></div><div class="astat"><span>🏪</span><b>${fmt(s.total_listings||0)}</b><small>E'lonlar</small></div><div class="astat"><span>🪙</span><b>${fmt(s.market_volume_7d_ball||0)}</b><small>7kun savdo</small></div><div class="astat"><span>💎</span><b>${fmt(s.total_diamonds_issued||0)}</b><small>Diamond</small></div><div class="astat"><span>🎰</span><b>${fmt(s.jackpot_pool||0)}</b><small>Jackpot fond</small></div></div><h3 class="admin-section-title">📋 So'nggi faoliyat</h3><div id="aTxList"></div>`;(s.recent_activity||[]).slice(0,10).forEach(tx=>{const r=el('div','admin-tx-row');r.innerHTML=`<span class="atx-type">${esc(tx.type||'')}</span><span class="atx-curr">${esc(tx.currency||'')}</span><b class="atx-amt" style="color:${tx.amount>0?'var(--green)':'var(--rose)'}">${tx.amount>0?'+':''}${fmt(tx.amount)}</b><small class="atx-time">${new Date(tx.created_at).toLocaleString('uz')}</small>`;$('aTxList').appendChild(r);});}catch(e){viewError(c,e.message,()=>loadATab('dashboard'));}}

async function aTabUsers(c){
  c.innerHTML=`<div class="admin-search-row"><input class="textfield" id="uSearch" placeholder="Ism yoki ID..." style="margin:0;flex:1"><button class="cta" id="uSBtn" style="padding:11px 14px">🔍</button></div><div class="tabs" style="margin:8px 0"><button class="tab active" data-us="all">Barchasi</button><button class="tab" data-us="banned">Banned</button><button class="tab" data-us="vip">VIP</button></div><div id="aUList" style="display:flex;flex-direction:column;gap:8px;margin-top:4px"></div>`;
  let status='all';
  async function load(q=''){const list=$('aUList');list.innerHTML='<p style="color:var(--dim);text-align:center;padding:12px">⏳</p>';try{const users=await api(`/admin/users?search=${encodeURIComponent(q)}&status=${status}`);list.innerHTML='';if(!users.length){list.innerHTML=noItems('Topilmadi');return;}users.forEach(u=>{const row=el('div','admin-user-row');row.innerHTML=`<div class="admin-user-info"><b>${esc(u.name)} ${u.is_admin?'👑':''} ${u.vip?'⭐':''} ${u.banned?'🚫':''}</b><small>ID:${u.telegram_id} • Lv.${u.level} • 🪙${fmt(u.ball)} • 💎${fmt(u.diamond)} • 🔑${u.keys}</small><small style="color:${RARITY_CLR.Special}">⚔️ ${fmt(u.achko)} • ${esc(u.rank_title||'Newbie')}</small></div><div class="admin-user-actions"></div>`;const acts=row.querySelector('.admin-user-actions');const bBtn=el('button',`admin-btn ${u.banned?'green':'red'}`,u.banned?'✅':'🚫');bBtn.onclick=async()=>{try{await api(`/admin/users/${u.id}/${u.banned?'unban':'ban'}`,'POST');toast(`✅ ${u.banned?'Oqlandi':'Banned'}!`,'success');load(q);}catch(e){toast('❌ '+e.message,'error');}};const balBtn=el('button','admin-btn blue','💰');balBtn.onclick=async()=>{const cur=prompt('Valyuta (ball/diamond/keys/xp/achko):','ball');if(!cur)return;const amt=prompt(`${cur} miqdori:`,'+1000');if(!amt||isNaN(amt))return;try{await api(`/admin/users/${u.id}/balance`,'POST',{currency:cur,amount:parseInt(amt)});toast('✅ Balans o\'zgartirildi','success');load(q);}catch(e){toast('❌ '+e.message,'error');}};acts.append(bBtn,balBtn);list.appendChild(row);});}catch(e){viewError(list,e.message,()=>load(q));}}
  $('uSBtn').onclick=()=>load($('uSearch').value);$('uSearch').onkeydown=e=>{if(e.key==='Enter')load($('uSearch').value);};
  c.querySelectorAll('[data-us]').forEach(t=>{t.onclick=()=>{c.querySelectorAll('[data-us]').forEach(x=>x.classList.remove('active'));t.classList.add('active');status=t.dataset.us;load($('uSearch')?.value||'');};});load();
}

async function aTabCards(c){
  c.innerHTML=`<button class="cta" id="btnAddCard" style="width:100%;margin-bottom:12px">➕ Yangi karta qo'shish</button><div id="aCrdList" style="display:flex;flex-direction:column;gap:8px"></div>`;
  $('btnAddCard').onclick=showAddCardForm;
  try{const cards=await api('/cards');const list=$('aCrdList');if(!cards.length){list.innerHTML=noItems('Kartalar yo\'q');return;}cards.forEach(card=>{const row=el('div','admin-card-row');const thumb=el('div',`admin-card-thumb r-${card.rarity}`);if(card.image_url)thumb.style.cssText=`background-image:url(${card.image_url});background-size:cover;background-position:center`;else thumb.textContent=RARITY_EMOJI[card.rarity]||'🌸';const info=el('div','',`<b style="font-size:12px">${esc(card.name)}</b><br><small style="color:${RARITY_CLR[card.rarity]}">${card.rarity}</small><small> • 🪙${fmt(card.base_price_ball)}</small>`);info.style.flex='1';const acts=el('div','admin-card-actions');const dBtn=el('button','admin-btn blue','⏳');dBtn.title='Drop yaratish';dBtn.onclick=async()=>{const h=prompt('Necha soat?','24');if(!h||isNaN(h))return;try{await api('/admin/drops','POST',{card_template_id:card.id,hours:parseInt(h)});toast('✅ Drop yaratildi','success');}catch(e){toast('❌ '+e.message,'error');}};const delBtn=el('button','admin-btn red','🗑️');delBtn.onclick=async()=>{if(!confirm(`"${card.name}" o'chirilsinmi?`))return;try{await api(`/admin/cards/${card.id}`,'DELETE');toast('✅ O\'chirildi','success');allCards=[];aTabCards(c);}catch(e){toast('❌ '+e.message,'error');}};acts.append(dBtn,delBtn);row.append(thumb,info,acts);list.appendChild(row);});}catch(e){viewError($('aCrdList'),e.message,()=>aTabCards(c));}
}

function showAddCardForm(){
  const overlay=$('cardModal');overlay.hidden=false;overlay.innerHTML='';const sheet=el('div','cardmodal-sheet');sheet.style.padding='20px 18px 28px';
  sheet.innerHTML=`<h2 class="cardmodal-name" style="margin:0 0 12px">➕ Yangi Karta</h2><input class="textfield" id="nCode" placeholder="Kod (SP-01)"><input class="textfield" id="nName" placeholder="Karta nomi"><input class="textfield" id="nAnime" placeholder="Anime nomi"><select class="textfield" id="nRarity"><option>Ordinary</option><option>Rare</option><option selected>Special</option><option>Legend</option><option>Galaxy</option><option>Unique</option></select><input class="textfield" type="number" id="nPrice" value="1000" placeholder="Ball narxi"><input class="textfield" id="nImg" placeholder="Rasm URL (ixtiyoriy)"><div style="display:flex;gap:10px;margin-top:2px"><label style="font-size:11px;display:flex;align-items:center;gap:4px"><input type="checkbox" id="nChest" checked> Sandiqdan</label><label style="font-size:11px;display:flex;align-items:center;gap:4px"><input type="checkbox" id="nSell" checked> Sotiladi</label></div>`;
  const save=el('button','cta','💾 Saqlash');save.style.cssText='width:100%;margin-top:12px';
  save.onclick=async()=>{const b={code:$('nCode').value.trim(),name:$('nName').value.trim(),anime:$('nAnime').value.trim(),rarity:$('nRarity').value,base_price_ball:parseInt($('nPrice').value)||1000,image_url:$('nImg').value.trim(),chest_drop:$('nChest').checked,sellable:$('nSell').checked};if(!b.code||!b.name){toast('Kod va nom kerak!','error');return;}try{await api('/admin/cards','POST',b);toast('✅ Karta yaratildi!','success');overlay.hidden=true;allCards=[];}catch(e){toast('❌ '+e.message,'error');}};
  const close=el('button','cardmodal-close','✕');close.onclick=()=>overlay.hidden=true;sheet.append(save,close);overlay.appendChild(sheet);overlay.onclick=e=>{if(e.target===overlay)overlay.hidden=true;};
}

async function aTabAI(c){
  c.innerHTML=`<div class="panel" style="margin-bottom:14px"><div class="panelhead">🤖 Gemini AI Karta Generator</div>
    <label style="font-size:10px;color:var(--dim);display:block;margin-bottom:3px">Gemini API kaliti</label>
    <input class="textfield" type="password" id="gKey" placeholder="AIza...">
    <label style="font-size:10px;color:var(--dim);display:block;margin-bottom:3px">Karta nomi</label>
    <input class="textfield" id="gName" placeholder="Masalan: Zero Two">
    <label style="font-size:10px;color:var(--dim);display:block;margin-bottom:3px">Anime</label>
    <input class="textfield" id="gAnime" placeholder="Darling in the FranXX">
    <label style="font-size:10px;color:var(--dim);display:block;margin-bottom:3px">Rarity</label>
    <select class="textfield" id="gRarity"><option>Ordinary</option><option>Rare</option><option selected>Special</option><option>Legend</option><option>Galaxy</option><option>Unique</option></select>
    <button class="cta" id="gGenBtn" style="width:100%;margin-top:6px">🎨 AI Rasm Yaratish</button>
    <div id="gPreview" style="margin-top:12px;text-align:center"></div>
    <button class="cta" id="gSaveBtn" style="width:100%;margin-top:10px;display:none">💾 Kartani Saqlash</button></div>
  <div class="panel"><div class="panelhead">⚙️ Tizim Gemini Kaliti</div>
    <input class="textfield" type="password" id="sGKey" placeholder="AIza...">
    <button class="cta" id="sSaveBtn" style="width:100%">💾 Saqlash</button>
    <div id="sStatus" style="margin-top:6px;font-size:11px;color:var(--dim)"></div></div>`;
  let genUrl='';
  $('gGenBtn').onclick=async()=>{const key=$('gKey').value.trim(),name=$('gName').value.trim();if(!key||!name){toast('Kalit va nom kerak!','error');return;}const btn=$('gGenBtn');btn.textContent='⏳ Yaratilmoqda...';btn.disabled=true;$('gPreview').innerHTML='<div class="skeleton-line" style="height:220px;border-radius:14px"></div>';try{const r=await api('/admin/cards/generate-image','POST',{name,anime:$('gAnime').value.trim(),rarity:$('gRarity').value,gemini_api_key:key});genUrl=r.image_url||'';$('gPreview').innerHTML=`<img src="${genUrl}" style="width:100%;max-width:300px;border-radius:14px;border:2px solid var(--violet2);box-shadow:0 8px 32px rgba(139,61,255,.4)">`;$('gSaveBtn').style.display='';}catch(e){$('gPreview').innerHTML=`<p style="color:var(--rose)">❌ ${esc(e.message)}</p>`;}btn.textContent='🎨 AI Rasm Yaratish';btn.disabled=false;};
  $('gSaveBtn').onclick=async()=>{const rar=$('gRarity').value;const pm={Ordinary:1000,Rare:2500,Special:5000,Legend:9000,Galaxy:14000,Unique:40000};try{await api('/admin/cards','POST',{code:'AI-'+Date.now().toString(36).toUpperCase().slice(-6),name:$('gName').value.trim(),anime:$('gAnime').value.trim(),rarity:rar,base_price_ball:pm[rar]||1000,image_url:genUrl,chest_drop:true,sellable:true});toast('✅ AI karta saqlandi!','success');$('gSaveBtn').style.display='none';$('gPreview').innerHTML='';allCards=[];}catch(e){toast('❌ '+e.message,'error');}};
  $('sSaveBtn').onclick=async()=>{const k=$('sGKey').value.trim();if(!k)return;try{await api('/admin/settings','POST',{key:'gemini_api_key',value:k});toast('✅ Kalit saqlandi','success');$('sStatus').textContent='✅ Saqlangan';$('sGKey').value='';}catch(e){toast('❌ '+e.message,'error');}};
  try{const s=await api('/admin/settings');if((s||[]).find(x=>x.key==='gemini_api_key'))$('sStatus').textContent='✅ Kalit saqlangan';}catch(_){}
}

async function aTabDrops(c){
  c.innerHTML=`<h3 class="admin-section-title">⏳ Faol Featured Drops</h3><div id="aDropList" style="display:flex;flex-direction:column;gap:8px"></div>`;
  try{const drops=await api('/market/featured');const list=$('aDropList');if(!drops.length){list.innerHTML=noItems('Faol drop yo\'q');return;}drops.forEach(d=>{const row=el('div','admin-card-row');const thumb=el('div','admin-card-thumb');thumb.textContent='⭐';const info=el('div','',`<b style="font-size:12px">${esc(d.card_name||'Karta')}</b><br><small>Tugaydi: ${new Date(d.ends_at).toLocaleString('uz')}</small>`);info.style.flex='1';const btn=el('button','admin-btn red','🔴 Tugatish');btn.onclick=async()=>{try{await api(`/admin/drops/${d.id}/resolve`,'POST',{decision:'retire'});toast('✅ Drop tugatildi','success');aTabDrops(c);}catch(e){toast('❌ '+e.message,'error');}};row.append(thumb,info,btn);list.appendChild(row);});}catch(e){viewError(c,e.message,()=>loadATab('drops'));}
}

/* ═══════════════════════════════════════════════════════════════
   CARD EVENT OVERLAY
═══════════════════════════════════════════════════════════════ */
function showCardEvent(type,card){
  if(!card)return;const overlay=$('cardEventOverlay');overlay.hidden=false;overlay.setAttribute('data-type',type);
  const titles={bought:'Sotib olindi! 🛒',sold:'Sotildi! 💰',returned:'Qaytarildi!',gifted:'Sovg\'a qilindi! 🎁',added:'Yangi karta! ✨'};
  const subs={bought:`${esc(card.name)} kolleksiyangizga qo'shildi`,sold:'Kartangiz sotildi',returned:'Karta qaytarildi',gifted:`${esc(card.name)} yuborildi`,added:`${esc(card.name)} sandiqdan chiqdi!`};
  overlay.querySelector('.cardevent-title').textContent=titles[type]||'';overlay.querySelector('.cardevent-sub').textContent=subs[type]||'';
  overlay.querySelector('.cardevent-rarity').textContent=card.rarity||'';overlay.querySelector('.cardevent-rarity').style.color=RARITY_CLR[card.rarity]||'#fff';
  overlay.querySelector('.cardevent-name').textContent=card.name||'';overlay.querySelector('.cardevent-id').textContent=card.code||'';
  const artEl=overlay.querySelector('.cardevent-art');
  if(card.image_url){artEl.style.cssText=`background-image:url(${card.image_url});background-size:cover;background-position:center;height:140px;border-radius:12px;margin-bottom:8px`;artEl.textContent='';}
  else{artEl.style.cssText='font-size:56px;text-align:center;padding:12px 0';artEl.textContent=RARITY_EMOJI[card.rarity]||'🌸';}
  const conf=overlay.querySelector('.cardevent-confetti');conf.innerHTML='';
  const isSpecial=card.rarity==='Galaxy'||card.rarity==='Unique';
  for(let i=0;i<20;i++){const s=document.createElement('span');if(isSpecial){s.textContent=['❄️','✨','💎','⭐','🌟'][i%5];s.style.cssText=`left:${Math.random()*100}%;top:-10%;font-size:14px;position:absolute;animation:cardevent-fall ${1.5+Math.random()}s ease-in ${Math.random()*.5}s 1 forwards`;}else{s.style.cssText=`left:${Math.random()*100}%;top:-10%;position:absolute;width:${6+Math.random()*6}px;height:${10+Math.random()*8}px;background:hsl(${Math.random()*360},70%,60%);border-radius:2px;animation:cardevent-fall ${1.5+Math.random()}s ease-in ${Math.random()*.5}s 1 forwards`;}conf.appendChild(s);}
  overlay.querySelector('.cardevent-btn').onclick=()=>overlay.hidden=true;
}

/* ═══════════════════════════════════════════════════════════════
   SNOW & RIPPLE
═══════════════════════════════════════════════════════════════ */
function initSnow(){const cv=$('snowCanvas');if(!cv)return;const ctx=cv.getContext('2d');let W,H;const fl=Array.from({length:55},()=>({x:Math.random()*1000,y:Math.random()*1000,r:.8+Math.random()*2,s:.3+Math.random()*.7,d:(Math.random()-.5)*.3,op:.2+Math.random()*.5}));const rs=()=>{W=cv.width=window.innerWidth;H=cv.height=window.innerHeight;};rs();window.addEventListener('resize',rs);(function draw(){ctx.clearRect(0,0,W,H);fl.forEach(f=>{ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,Math.PI*2);ctx.fillStyle=`rgba(220,240,255,${f.op})`;ctx.fill();f.y+=f.s;f.x+=f.d;if(f.y>H+8){f.y=-8;f.x=Math.random()*W;}});requestAnimationFrame(draw);})();}

function setupRipple(){document.addEventListener('pointerdown',e=>{const b=e.target.closest('button,.cta,.qcard,.cardtile,.tab,.navbtn,.listrow,.gametile,.qbtn');if(!b)return;b.style.position='relative';b.style.overflow='hidden';const c=document.createElement('span');const r=Math.max(b.offsetWidth,b.offsetHeight);const rect=b.getBoundingClientRect();c.style.cssText=`position:absolute;border-radius:50%;pointer-events:none;background:rgba(255,255,255,.18);width:${r*2}px;height:${r*2}px;left:${e.clientX-rect.left-r}px;top:${e.clientY-rect.top-r}px;transform:scale(0);animation:rippleGrow .55s ease-out forwards`;b.appendChild(c);setTimeout(()=>c.remove(),600);});}
