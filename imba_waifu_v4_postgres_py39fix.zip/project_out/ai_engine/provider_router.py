"""
Placeholder for the real AI market-pricing engine (spec: 05_BACKEND_ARCHITECTURE.md
mentions an ai_engine module with a provider_router). For now this is a simple
rule-based estimate so the rest of the system (market listings) has something
real to call. Swap the body of `suggest_price` for an actual model/provider
call later without touching any other file.
"""
import base64
import json
import random
from typing import Optional, Set, List, Dict

import requests

RARITY_MULTIPLIER = {
    "Ordinary": 1.0, "Rare": 2.5, "Special": 5.0,
    "Legend": 9.0, "Galaxy": 14.0, "Unique": 40.0,
}

GEMINI_IMAGE_MODEL = "gemini-3.1-flash-image"
GEMINI_ENDPOINT = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_IMAGE_MODEL}:generateContent"
GEMINI_TEXT_MODEL = "gemini-2.5-flash"
GEMINI_TEXT_ENDPOINT = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_TEXT_MODEL}:generateContent"

# Used only if the Gemini text call fails (bad key, quota, network) — original
# names, not real series, so the daily job never has to stop for a copyright
# question just to keep posting something.
FALLBACK_ANIME_POOL = [
    {"name": "Akira Kurotsuki", "anime": "Original / Fallback"},
    {"name": "Yumi Hoshikawa", "anime": "Original / Fallback"},
    {"name": "Ren Fujimori", "anime": "Original / Fallback"},
    {"name": "Sora Amaterasu", "anime": "Original / Fallback"},
    {"name": "Kaida Ryuzaki", "anime": "Original / Fallback"},
    {"name": "Mika Shirogane", "anime": "Original / Fallback"},
    {"name": "Haruto Kazehaya", "anime": "Original / Fallback"},
    {"name": "Nozomi Tsukikage", "anime": "Original / Fallback"},
]


def suggest_price(card_template, sellers_asking_price: Optional[int] = None) -> float:
    """Returns an AI-suggested fair price in Ball for a card template."""
    # base_price_ball in our seed data already reflects rarity, so it's the anchor
    suggested = float(card_template.base_price_ball)
    if sellers_asking_price:
        # nudge slightly toward the market's own signal, capped at +/-15%
        suggested = suggested * 0.7 + sellers_asking_price * 0.3
    return round(suggested, 0)


def generate_card_image(prompt: str, api_key: str, timeout: int = 60) -> tuple[bytes, str]:
    """
    Generates a card illustration via Gemini's image model and returns
    (raw_image_bytes, mime_type). Raises RuntimeError with a readable
    message on any failure (bad key, quota, no image in response, etc.)
    so the API layer can turn it into a clean HTTP error instead of a 500.

    Note: this endpoint/model name is current as of mid-2026 — Google
    renames these periodically, so if this starts failing, check
    https://ai.google.dev/gemini-api/docs/image-generation for the
    current model id and update GEMINI_IMAGE_MODEL above.
    """
    try:
        resp = requests.post(
            GEMINI_ENDPOINT,
            headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=timeout,
        )
    except requests.RequestException as e:
        raise RuntimeError(f"could not reach Gemini API: {e}")

    if resp.status_code != 200:
        raise RuntimeError(f"Gemini API error {resp.status_code}: {resp.text[:300]}")

    data = resp.json()
    try:
        parts = data["candidates"][0]["content"]["parts"]
    except (KeyError, IndexError):
        raise RuntimeError(f"unexpected Gemini response shape: {str(data)[:300]}")

    for part in parts:
        inline = part.get("inlineData") or part.get("inline_data")
        if inline and inline.get("data"):
            mime = inline.get("mimeType") or inline.get("mime_type") or "image/png"
            return base64.b64decode(inline["data"]), mime

    raise RuntimeError("Gemini response contained no image data")


def suggest_anime_characters(api_key: str, count: int = 5, exclude: Optional[Set] = None, timeout: int = 30) -> List[Dict]:
    """
    Asks Gemini's text model for `count` anime-style character ideas for the
    daily card curator. Returns [{"name": ..., "anime": ...}, ...].

    Never raises: any failure (bad key, quota, unparsable response) falls
    back to FALLBACK_ANIME_POOL so the daily posting job never silently does
    nothing just because one API call had a bad day.
    """
    exclude = exclude or set()
    prompt = (
        f"Suggest {count} anime-style characters for a trading-card game, mixing "
        f"well-known and lesser-known series for variety. Avoid these already-used "
        f"names: {', '.join(list(exclude)[:50]) if exclude else 'none'}. "
        'Respond ONLY with a JSON array like [{"name": "...", "anime": "..."}], no other text.'
    )
    try:
        resp = requests.post(
            GEMINI_TEXT_ENDPOINT,
            headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=timeout,
        )
        resp.raise_for_status()
        raw = resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()
        parsed = json.loads(raw)
        cleaned = [
            {"name": p["name"], "anime": p.get("anime", "")}
            for p in parsed if p.get("name") and p["name"] not in exclude
        ]
        if len(cleaned) >= count:
            return cleaned[:count]
    except Exception:
        pass  # fall through to the fixed pool below

    pool = [p for p in FALLBACK_ANIME_POOL if p["name"] not in exclude]
    random.shuffle(pool)
    return pool[:count]
