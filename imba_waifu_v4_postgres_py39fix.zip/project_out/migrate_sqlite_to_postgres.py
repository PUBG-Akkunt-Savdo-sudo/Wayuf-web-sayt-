#!/usr/bin/env python3
"""
migrate_sqlite_to_postgres.py — SQLite → PostgreSQL ma'lumotlarni ko'chirish.

Ishlatish:
  pip install sqlalchemy psycopg2-binary python-dotenv --break-system-packages
  python migrate_sqlite_to_postgres.py
"""
import sys
import os

# Muhit o'zgaruvchilarini yuklash
from dotenv import load_dotenv
load_dotenv()

SQLITE_URL  = "sqlite:///./imbawaifu.db"
POSTGRES_URL = os.getenv("DATABASE_URL", "")

if not POSTGRES_URL or "sqlite" in POSTGRES_URL:
    print("❌ .env faylida DATABASE_URL=postgresql://... bo'lishi kerak!")
    sys.exit(1)

from sqlalchemy import create_engine, text, inspect
from sqlalchemy.orm import sessionmaker

print("🔄 SQLite → PostgreSQL migratsiya boshlanmoqda...")
print(f"   Manba  : {SQLITE_URL}")
print(f"   Maqsad : {POSTGRES_URL[:40]}...")
print()

# Ulanishlar
src_engine  = create_engine(SQLITE_URL, connect_args={"check_same_thread": False})
dst_engine  = create_engine(POSTGRES_URL, pool_pre_ping=True)
SrcSession  = sessionmaker(bind=src_engine)
DstSession  = sessionmaker(bind=dst_engine)

# Jadvallarni to'g'ri tartibda ko'chirish (FK munosabatlari hisobga olingan)
TABLE_ORDER = [
    "users",
    "card_templates",
    "card_ownerships",
    "market_listings",
    "transactions",
    "chat_messages",
    "admin_settings",
    "featured_drops",
    "jackpots",
]

def get_existing_tables(engine):
    inspector = inspect(engine)
    return set(inspector.get_table_names())

src_tables = get_existing_tables(src_engine)
dst_tables = get_existing_tables(dst_engine)

if not dst_tables:
    print("⚠️  PostgreSQL jadvallar topilmadi.")
    print("   Avval backend'ni bir marta ishga tushiring:")
    print("   cd backend && python -c 'from app.core.database import init_db; init_db()'")
    sys.exit(1)

migrated_total = 0

with src_engine.connect() as src_conn, dst_engine.connect() as dst_conn:
    for table in TABLE_ORDER:
        if table not in src_tables:
            print(f"   ⏭  {table} — SQLite'da yo'q, o'tkazib yuborildi")
            continue

        rows = src_conn.execute(text(f"SELECT * FROM {table}")).fetchall()
        if not rows:
            print(f"   ○  {table} — bo'sh, o'tkazib yuborildi")
            continue

        cols = src_conn.execute(text(f"SELECT * FROM {table} LIMIT 0")).keys()
        col_list   = ", ".join(cols)
        placeholders = ", ".join([f":{c}" for c in cols])

        # Maqsad jadvalini tozalash (agar allaqachon ma'lumot bo'lsa)
        dst_count = dst_conn.execute(text(f"SELECT COUNT(*) FROM {table}")).scalar()
        if dst_count > 0:
            ans = input(f"   ⚠️  {table} jadvalida {dst_count} ta yozuv bor. O'chirib ko'chirasizmi? [y/N] ")
            if ans.strip().lower() != "y":
                print(f"   ⏭  {table} — o'tkazib yuborildi")
                continue
            dst_conn.execute(text(f"TRUNCATE TABLE {table} RESTART IDENTITY CASCADE"))
            dst_conn.commit()

        # Qo'shish
        batch = [dict(zip(cols, row)) for row in rows]
        dst_conn.execute(
            text(f"INSERT INTO {table} ({col_list}) VALUES ({placeholders})"),
            batch,
        )
        dst_conn.commit()

        # Sequence'ni to'g'rilash (PostgreSQL SERIAL uchun)
        try:
            dst_conn.execute(text(
                f"SELECT setval(pg_get_serial_sequence('{table}', 'id'), "
                f"COALESCE((SELECT MAX(id) FROM {table}), 0) + 1, false)"
            ))
            dst_conn.commit()
        except Exception:
            pass  # id ustuni yo'q jadvallar uchun

        migrated_total += len(batch)
        print(f"   ✅ {table:30s} — {len(batch):>5} ta yozuv ko'chirildi")

print()
print(f"✅ Migratsiya tugadi! Jami {migrated_total} ta yozuv ko'chirildi.")
print()
print("Keyingi qadam: .env faylida DATABASE_URL=postgresql://... ekanini tekshiring")
print("va backendni qayta ishga tushiring.")
