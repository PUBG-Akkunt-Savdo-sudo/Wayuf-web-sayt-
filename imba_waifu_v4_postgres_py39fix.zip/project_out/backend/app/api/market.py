from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.card import CardTemplate, MarketListing
from app.models.user import User
from app.services import market_service, drop_service

router = APIRouter(prefix="/api/market", tags=["market"])


class ListRequest(BaseModel):
    ownership_id: int
    price_ball: int


class GiftRequest(BaseModel):
    ownership_id: int
    recipient_telegram_id: int


@router.get("/shop")
def shop(db: Session = Depends(get_db)):
    """
    House catalog. Regular cards are always here. Cards marked
    is_limited only appear while they have an active FeaturedDrop
    window (PUBG/DLS-style rotating rare item) — resolve_expired_drops
    runs first so a just-expired window doesn't show stale results.
    """
    drop_service.resolve_expired_drops(db)
    active_ids = drop_service.active_card_ids(db)

    all_cards = db.query(CardTemplate).filter(CardTemplate.visibility_rule == "public").all()
    visible = [c for c in all_cards if not c.is_limited or c.id in active_ids]
    return [c.public_dict() for c in visible]


@router.get("/featured")
def featured_drops(db: Session = Depends(get_db)):
    """Currently active limited-time card windows, for the Home screen banner."""
    from app.models.featured_drop import FeaturedDrop
    drop_service.resolve_expired_drops(db)
    now_active = db.query(FeaturedDrop).filter(FeaturedDrop.status == "active").all()
    return [d.public_dict() for d in now_active]


@router.post("/shop/buy/{template_id}")
def shop_buy(template_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    drop_service.resolve_expired_drops(db)
    card = db.query(CardTemplate).filter(CardTemplate.id == template_id).first()
    if card and card.is_limited and template_id not in drop_service.active_card_ids(db):
        raise HTTPException(400, "this card's limited window has ended")
    try:
        ownership = market_service.buy_from_shop(db, user, template_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ownership_id": ownership.id, "user": user.public_dict()}


@router.get("/listings")
def listings(db: Session = Depends(get_db)):
    rows = db.query(MarketListing).filter(MarketListing.status == "active").all()
    return [{
        "id": l.id, "price_ball": l.price_ball, "ai_suggested_price": l.ai_suggested_price,
        "seller_id": l.seller_id, "seller_name": l.seller.name,
        "card": l.ownership.template.public_dict(),
    } for l in rows]


@router.get("/my-listings")
def my_listings(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(MarketListing).filter(MarketListing.seller_id == user.id, MarketListing.status == "active").all()
    return [{"id": l.id, "price_ball": l.price_ball, "card": l.ownership.template.public_dict()} for l in rows]


@router.post("/list")
def create_listing(body: ListRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    try:
        listing = market_service.list_for_sale(db, user, body.ownership_id, body.price_ball)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"id": listing.id, "ai_suggested_price": listing.ai_suggested_price}


@router.post("/buy/{listing_id}")
def buy_listing(listing_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    try:
        listing = market_service.buy_listing(db, user, listing_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"listing_id": listing.id, "status": listing.status, "user": user.public_dict()}


@router.post("/cancel/{listing_id}")
def cancel_listing(listing_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    try:
        listing = market_service.cancel_listing(db, user, listing_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"listing_id": listing.id, "status": listing.status}


@router.post("/gift")
def gift_card(body: GiftRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """
    Foydalanuvchidan foydalanuvchiga karta yuborish.
    recipient_telegram_id — qabul qiluvchining Telegram ID raqami.
    """
    try:
        ownership = market_service.gift_card(db, user, body.ownership_id, body.recipient_telegram_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {
        "ownership_id": ownership.id,
        "template": ownership.template.public_dict(),
    }
