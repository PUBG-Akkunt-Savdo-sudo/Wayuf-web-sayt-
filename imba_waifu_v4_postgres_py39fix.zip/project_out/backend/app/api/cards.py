from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.card import CardTemplate, CardOwnership
from app.models.user import User

router = APIRouter(prefix="/api/cards", tags=["cards"])


@router.get("")
def list_cards(rarity: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(CardTemplate).filter(CardTemplate.visibility_rule == "public")
    if rarity:
        q = q.filter(CardTemplate.rarity == rarity)
    return [c.public_dict() for c in q.all()]


@router.get("/mine")
def my_cards(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned = db.query(CardOwnership).filter(CardOwnership.owner_id == user.id).all()
    return [
        {"ownership_id": o.id, "acquired_at": o.acquired_at.isoformat(), **o.template.public_dict()}
        for o in owned
    ]
