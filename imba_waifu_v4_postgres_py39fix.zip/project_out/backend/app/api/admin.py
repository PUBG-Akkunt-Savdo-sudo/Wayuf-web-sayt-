import base64
from datetime import datetime, timedelta
from typing import Optional

import requests as http_requests
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, cast, String
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.security import get_current_admin
from app.models.user import User
from app.models.card import CardTemplate, MarketListing
from app.models.transaction import Transaction
from app.models.chat import ChatMessage
from app.models.admin_setting import AdminSetting
from app.services.economy_service import change_balance, admin_adjust_balance
from app.services import drop_service, ai_curator_service
from ai_engine.provider_router import generate_card_image

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ---------------------------------------------------------------- dashboard
@router.get("/dashboard")
def dashboard(user: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    total_users = db.query(func.count(User.id)).scalar()
    total_cards = db.query(func.count(CardTemplate.id)).scalar()
    since = datetime.utcnow() - timedelta(days=7)
    market_volume_7d = db.query(func.coalesce(func.sum(MarketListing.price_ball), 0)).filter(
        MarketListing.status == "sold", MarketListing.sold_at >= since
    ).scalar()
    recent_tx = db.query(Transaction).order_by(Transaction.id.desc()).limit(10).all()
    return {
        "total_users": total_users,
        "total_cards": total_cards,
        "market_volume_7d_ball": market_volume_7d,
        "recent_activity": [
            {"type": t.type, "currency": t.currency, "amount": t.amount, "user_id": t.user_id,
             "created_at": t.created_at.isoformat()} for t in recent_tx
        ],
    }


# ---------------------------------------------------------------- users
@router.get("/users")
def list_users(search: str = "", status: str = "all", user: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    q = db.query(User)
    if search:
        q = q.filter((User.name.ilike(f"%{search}%")) | (cast(User.telegram_id, String).ilike(f"%{search}%")))
    if status == "banned":
        q = q.filter(User.banned.is_(True))
    elif status == "admin":
        q = q.filter(User.is_admin.is_(True))
    elif status == "vip":
        q = q.filter(User.vip.is_(True))
    return [u.public_dict() for u in q.order_by(User.id.desc()).limit(200).all()]


class BalanceAdjust(BaseModel):
    currency: str  # ball | diamond | keys | xp | achko
    amount: int    # can be negative


@router.post("/users/{user_id}/balance")
def adjust_balance(user_id: int, body: BalanceAdjust, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(404, "user not found")
    if body.currency not in {"ball", "diamond", "keys", "xp", "achko"}:
        raise HTTPException(400, "invalid currency")
    try:
        admin_adjust_balance(db, target, body.currency, body.amount, admin)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return target.public_dict()


@router.post("/users/{user_id}/ban")
def ban_user(user_id: int, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(404, "user not found")
    target.banned = True
    db.commit()
    return {"ok": True}


@router.post("/users/{user_id}/unban")
def unban_user(user_id: int, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(404, "user not found")
    target.banned = False
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- settings (AI key etc.)
class SettingBody(BaseModel):
    key: str
    value: str


@router.get("/settings")
def get_settings(admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    rows = db.query(AdminSetting).all()
    # never return raw secret values to the frontend — only whether they're set
    return [{"key": r.key, "is_set": bool(r.value), "updated_at": r.updated_at.isoformat()} for r in rows]


@router.post("/settings")
def set_setting(body: SettingBody, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    row = db.query(AdminSetting).filter(AdminSetting.key == body.key).first()
    if row:
        row.value = body.value
    else:
        row = AdminSetting(key=body.key, value=body.value)
        db.add(row)
    db.commit()
    return {"ok": True}


def _get_setting(db: Session, key: str) -> Optional[str]:
    row = db.query(AdminSetting).filter(AdminSetting.key == key).first()
    return row.value if row else None


# ---------------------------------------------------------------- cards + AI creator
class CardCreate(BaseModel):
    code: str
    name: str
    anime: str = ""
    rarity: str
    base_price_diamond: int = 0
    base_price_ball: int = 1000
    supply: Optional[int] = None          # informational for now (not enforced as a hard cap yet)
    image_url: str = ""                # can be filled in after calling /cards/generate-image
    chest_drop: bool = True
    sellable: bool = True


@router.post("/cards")
def create_card(body: CardCreate, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    if db.query(CardTemplate).filter(CardTemplate.code == body.code).first():
        raise HTTPException(400, "card code already exists")
    card = CardTemplate(
        code=body.code, name=body.name, anime=body.anime, rarity=body.rarity,
        base_price_diamond=body.base_price_diamond, base_price_ball=body.base_price_ball,
        image_url=body.image_url, chest_drop=body.chest_drop, sellable=body.sellable,
    )
    db.add(card)
    db.commit()
    db.refresh(card)
    return card.public_dict()


class GenerateImageBody(BaseModel):
    name: str
    anime: str = ""
    rarity: str = "Ordinary"
    extra_prompt: str = ""


@router.post("/cards/generate-image")
def generate_image(body: GenerateImageBody, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    """
    Generates card art with the admin's own Gemini API key (set via
    POST /api/admin/settings with key='gemini_api_key'). Returns a data URL
    the admin panel can preview immediately and save as the card's image_url.

    Note: storing images as base64 data URLs in the DB is fine for a handful
    of cards but gets heavy at scale — swap for real file/object storage
    (S3-compatible bucket, or just static files on the VPS) once the catalog
    grows past a few dozen cards.
    """
    api_key = _get_setting(db, "gemini_api_key")
    if not api_key:
        raise HTTPException(400, "Gemini API key not configured — set it in Admin Panel → Settings first")

    prompt = (
        f"A high-quality anime trading-card style portrait illustration of a character named "
        f"'{body.name}'" + (f" from the series '{body.anime}'" if body.anime else "") +
        f". Rarity tier: {body.rarity}. Vertical card composition, dramatic lighting, "
        f"detailed line art, vibrant colors matching a {body.rarity.lower()}-tier fantasy card game aesthetic. "
        f"{body.extra_prompt}".strip()
    )

    try:
        image_bytes, mime = generate_card_image(prompt, api_key)
    except RuntimeError as e:
        raise HTTPException(502, str(e))

    data_url = f"data:{mime};base64,{base64.b64encode(image_bytes).decode()}"
    return {"image_data_url": data_url, "prompt_used": prompt}


# ---------------------------------------------------------------- market / economy
@router.get("/market")
def market_overview(admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    active = db.query(func.count(MarketListing.id)).filter(MarketListing.status == "active").scalar()
    since = datetime.utcnow() - timedelta(days=7)
    sold_7d = db.query(MarketListing).filter(MarketListing.status == "sold", MarketListing.sold_at >= since).all()
    volume_7d = sum(l.price_ball for l in sold_7d)
    avg_price_7d = round(volume_7d / len(sold_7d), 0) if sold_7d else 0

    return {
        "active_listings": active,
        "volume_7d_ball": volume_7d,
        "avg_price_7d_ball": avg_price_7d,
        "sold_count_7d": len(sold_7d),
        "note": "Top-cards-by-volume ranking isn't wired up yet — needs a join across "
                "listings→ownerships→templates; flagging so it's not silently wrong.",
    }


# ---------------------------------------------------------------- payments / security (transaction log)
@router.get("/transactions")
def transactions(limit: int = 50, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    rows = db.query(Transaction).order_by(Transaction.id.desc()).limit(limit).all()
    return [{
        "id": t.id, "user_id": t.user_id, "type": t.type, "currency": t.currency,
        "amount": t.amount, "before_balance": t.before_balance, "after_balance": t.after_balance,
        "source": t.source, "created_at": t.created_at.isoformat(),
    } for t in rows]


# ---------------------------------------------------------------- chat moderation + broadcast
@router.get("/chat")
def admin_chat(room: str = "global", limit: int = 100, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    rows = db.query(ChatMessage).filter(ChatMessage.room == room).order_by(ChatMessage.id.desc()).limit(limit).all()
    return [m.public_dict() for m in reversed(rows)]


@router.delete("/chat/{message_id}")
def delete_message(message_id: int, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    msg = db.query(ChatMessage).filter(ChatMessage.id == message_id).first()
    if not msg:
        raise HTTPException(404, "message not found")
    db.delete(msg)
    db.commit()
    return {"ok": True}


class BroadcastBody(BaseModel):
    text: str
    target: str = "all"  # all | vip  (kept simple for MVP — "online now" isn't tracked)


@router.post("/broadcast")
def broadcast(body: BroadcastBody, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    if not settings.BOT_TOKEN:
        raise HTTPException(500, "BOT_TOKEN not configured")

    q = db.query(User).filter(User.notifications_enabled.is_(True), User.banned.is_(False))
    if body.target == "vip":
        q = q.filter(User.vip.is_(True))
    recipients = q.all()

    sent, failed = 0, 0
    url = f"https://api.telegram.org/bot{settings.BOT_TOKEN}/sendMessage"
    for u in recipients:
        try:
            r = http_requests.post(url, json={"chat_id": u.telegram_id, "text": body.text}, timeout=10)
            sent += 1 if r.ok else 0
            failed += 0 if r.ok else 1
        except http_requests.RequestException:
            failed += 1
    return {"sent": sent, "failed": failed, "total": len(recipients)}


# ---------------------------------------------------------------- limited-time card rotation
class FeatureCardBody(BaseModel):
    hours: int = 24


@router.post("/cards/{card_id}/feature")
def feature_card(card_id: int, body: FeatureCardBody, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    """Starts a limited-time window for this card (PUBG/DLS-style rotating rare item)."""
    try:
        drop = drop_service.create_drop(db, card_id, hours=body.hours, admin_id=admin.id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return drop.public_dict()


@router.get("/drops")
def list_drops(admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    from app.models.featured_drop import FeaturedDrop
    drop_service.resolve_expired_drops(db)
    rows = db.query(FeaturedDrop).order_by(FeaturedDrop.id.desc()).limit(100).all()
    return [d.public_dict() for d in rows]


class ResolveDropBody(BaseModel):
    decision: str  # "return" | "retire"


@router.post("/drops/{drop_id}/resolve")
def resolve_drop(drop_id: int, body: ResolveDropBody, admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    """
    Manual admin override for what happens after a drop's 24h window —
    force it to come back for another round or retire it now, instead of
    waiting for the automatic probability roll.
    """
    try:
        drop = drop_service.resolve_drop_manually(db, drop_id, body.decision)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return drop.public_dict()


# ---------------------------------------------------------------- AI curator (daily cards + prune)
@router.post("/ai-curator/run-now")
def run_ai_curator_now(admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    """Manually triggers today's 5-card AI drop, without waiting for the 03:00 cron.
    Needs gemini_api_key set in Settings first."""
    created = ai_curator_service.generate_daily_cards(db)
    return {"created": [c.public_dict() for c in created]}


@router.get("/ai-curator/prune-preview")
def prune_preview(admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    """Shows which cards WOULD be deleted by the prune job right now, without deleting anything.
    Only Ordinary-tier cards are ever candidates — everything else is protected."""
    return {"would_remove": ai_curator_service.prune_unpopular_cards(db, dry_run=True)}


@router.post("/ai-curator/prune-now")
def prune_now(admin: User = Depends(get_current_admin), db: Session = Depends(get_db)):
    """Actually runs the prune: deletes qualifying cards (and any remaining copies of them) now,
    instead of waiting for the 03:00 cron."""
    return {"removed": ai_curator_service.prune_unpopular_cards(db, dry_run=False)}
