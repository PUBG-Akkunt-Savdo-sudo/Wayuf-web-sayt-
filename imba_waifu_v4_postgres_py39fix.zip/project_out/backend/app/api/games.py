from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.services.game_service import play_game, current_jackpot_amount

router = APIRouter(prefix="/api/games", tags=["games"])


@router.get("/jackpot")
def jackpot_pool(db: Session = Depends(get_db)):
    """Current casino jackpot pool (Ball) — public, shown before playing so users know the stakes."""
    return {"pool_ball": current_jackpot_amount(db)}


@router.post("/play/{game_key}")
def play(game_key: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """game_key must be one of: wheel, jackpot, mini. (chest is opened via /api/chest, not here.)"""
    try:
        result = play_game(db, user, game_key)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {**result, "user": user.public_dict()}
