from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.services.chest_service import open_chest

router = APIRouter(prefix="/api/chest", tags=["chest"])


@router.post("/open")
def open_chest_endpoint(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    try:
        won = open_chest(db, user)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"won_card": won.public_dict(), "user": user.public_dict()}
