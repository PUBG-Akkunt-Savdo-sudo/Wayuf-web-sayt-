from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect, Query
from sqlalchemy.orm import Session

from app.core.database import get_db, SessionLocal
from app.core.security import get_current_user, verify_init_data
from app.core.config import settings
from app.models.user import User
from app.models.chat import ChatMessage

router = APIRouter(tags=["chat"])

ALLOWED_ROOMS = {"global", "friends"}


@router.get("/api/chat/history")
def history(room: str = "global", limit: int = 50, db: Session = Depends(get_db)):
    if room not in ALLOWED_ROOMS:
        raise HTTPException(400, "unknown room")
    rows = (
        db.query(ChatMessage)
        .filter(ChatMessage.room == room)
        .order_by(ChatMessage.id.desc())
        .limit(limit)
        .all()
    )
    return [m.public_dict() for m in reversed(rows)]


class ConnectionManager:
    """Keeps track of connected sockets per room, in-memory (MVP — fine for
    a single server process; swap for Redis pub/sub if you scale to >1 worker)."""

    def __init__(self):
        self.rooms: dict[str, list[WebSocket]] = {}

    async def connect(self, room: str, ws: WebSocket):
        await ws.accept()
        self.rooms.setdefault(room, []).append(ws)

    def disconnect(self, room: str, ws: WebSocket):
        if ws in self.rooms.get(room, []):
            self.rooms[room].remove(ws)

    async def broadcast(self, room: str, message: dict):
        for ws in list(self.rooms.get(room, [])):
            try:
                await ws.send_json(message)
            except Exception:
                self.disconnect(room, ws)


manager = ConnectionManager()


@router.websocket("/ws/chat")
async def chat_ws(websocket: WebSocket, init_data: str = Query(...), room: str = Query("global")):
    if room not in ALLOWED_ROOMS:
        await websocket.close(code=4000)
        return
    # Auth over query param since browsers can't set custom headers on WebSocket handshake
    try:
        tg_user = verify_init_data(init_data, settings.BOT_TOKEN)
    except ValueError:
        await websocket.close(code=4001)
        return

    db = SessionLocal()
    user = db.query(User).filter(User.telegram_id == tg_user["id"]).first()
    if not user:
        await websocket.close(code=4001)
        db.close()
        return

    await manager.connect(room, websocket)
    try:
        while True:
            data = await websocket.receive_json()
            text = (data.get("text") or "").strip()[:2000]
            if not text:
                continue
            msg = ChatMessage(room=room, user_id=user.id, text=text)
            db.add(msg)
            db.commit()
            db.refresh(msg)
            await manager.broadcast(room, msg.public_dict())
    except WebSocketDisconnect:
        manager.disconnect(room, websocket)
    finally:
        db.close()
