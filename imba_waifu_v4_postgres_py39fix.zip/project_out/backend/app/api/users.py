from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import get_current_user
from app.core.config import settings
from app.models.user import User
from app.services.economy_service import change_balance, add_xp

router = APIRouter(prefix="/api/users", tags=["users"])

MAX_AVATAR_LEN = 700_000  # ~500KB image as base64 data URL — enough for a small avatar, keeps DB rows sane


def _is_today(dt) -> bool:
    return bool(dt) and dt.date() == datetime.utcnow().date()


@router.get("/me")
def me(user: User = Depends(get_current_user)):
    return user.public_dict()


class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    avatar_url: Optional[str] = None   # data:image/...;base64,... or a plain image URL
    notifications_enabled: Optional[bool] = None


@router.put("/me")
def update_profile(body: ProfileUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if body.name is not None:
        name = body.name.strip()
        if not (1 <= len(name) <= 32):
            raise HTTPException(400, "name must be 1-32 characters")
        user.name = name
    if body.avatar_url is not None:
        if len(body.avatar_url) > MAX_AVATAR_LEN:
            raise HTTPException(400, "image too large — please use a smaller picture")
        user.avatar_url = body.avatar_url
    if body.notifications_enabled is not None:
        user.notifications_enabled = body.notifications_enabled
    db.commit()
    db.refresh(user)
    return user.public_dict()


@router.post("/daily-bonus")
def claim_daily_bonus(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if _is_today(user.daily_claimed_at):
        raise HTTPException(400, "already claimed today")
    change_balance(db, user, "ball", settings.DAILY_BONUS_BALL, "daily_bonus", source="user")
    add_xp(db, user, settings.DAILY_BONUS_XP)
    user.daily_claimed_at = datetime.utcnow()
    db.commit()
    db.refresh(user)
    return user.public_dict()


MISSIONS = {
    "m1": {"text": "3 ta o'yin o'ynash", "reward": 1000},
    "m2": {"text": "1 ta sandiq ochish", "reward": 2000},
    "m3": {"text": "1 ta karta almashtirish", "reward": 1500},
}


@router.post("/claim-mission/{mission_id}")
def claim_mission(mission_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # daily reset
    if not user.missions_reset_at or user.missions_reset_at.date() != datetime.utcnow().date():
        user.missions_done = []
        user.missions_reset_at = datetime.utcnow()

    if mission_id not in MISSIONS:
        raise HTTPException(404, "unknown mission")
    done = user.missions_done or []
    if mission_id in done:
        raise HTTPException(400, "mission already claimed today")

    reward = MISSIONS[mission_id]["reward"]
    change_balance(db, user, "ball", reward, "mission", source="user")
    done.append(mission_id)
    user.missions_done = done
    db.commit()
    db.refresh(user)
    return user.public_dict()
