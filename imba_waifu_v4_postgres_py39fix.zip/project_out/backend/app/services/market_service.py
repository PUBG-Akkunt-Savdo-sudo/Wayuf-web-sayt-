"""
market_service.py — Production-safe savdo operatsiyalari.

Xavfsizlik kafolatlari:
  1. SELECT … FOR UPDATE  — bir listingni ikki xaridor bir vaqtda ololmaydi
  2. Barcha pul operatsiyalari change_balance() orqali — balans hech qachon
     frontenddan kelmaydi, faqat server hisoblaydi
  3. Har bir operatsiya bitta DB tranzaksiyasida — qisman muvaffaqiyat yo'q
"""
from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from app.models.card import CardTemplate, CardOwnership, MarketListing
from app.models.user import User
from app.services.economy_service import change_balance, add_xp
from app.services import notify_service
from ai_engine.provider_router import suggest_price


# ── DO'KONDAN SOTIB OLISH ────────────────────────────────────────────────────
def buy_from_shop(db: Session, user: User, template_id: int) -> CardOwnership:
    """
    Uy katalogidan to'g'ridan-to'g'ri sotib olish.
    Xavfsizlik: foydalanuvchi qatori FOR UPDATE bilan qulflanadi,
    shuning uchun parallel so'rovlar balansni ikki marta aylana olmaydi.
    """
    # 1. Karta mavjudligini tekshir
    template = db.query(CardTemplate).filter(CardTemplate.id == template_id).first()
    if not template:
        raise ValueError("Karta topilmadi")

    # 2. Foydalanuvchi qatorini LOCK qil (parallel buy-lardan himoya)
    locked_user = (
        db.query(User)
        .filter(User.id == user.id)
        .with_for_update()
        .first()
    )
    if not locked_user:
        raise ValueError("Foydalanuvchi topilmadi")

    # 3. Balansni kamaytir (change_balance ichida ham tekshiriladi)
    change_balance(db, locked_user, "ball", -template.base_price_ball, "shop_buy", source="user")

    # 4. Mulkni yaratish
    ownership = CardOwnership(template_id=template.id, owner_id=locked_user.id)
    db.add(ownership)
    db.commit()
    db.refresh(ownership)

    # 5. XP bering
    add_xp(db, locked_user, 30)

    # user ob'ektini ham yangilang (caller uchun)
    db.refresh(user)
    return ownership


# ── MARKETGA QO'YISH ─────────────────────────────────────────────────────────
def list_for_sale(
    db: Session, user: User, ownership_id: int, price_ball: int
) -> MarketListing:
    """
    Foydalanuvchi o'z kartasini bozorga qo'yadi.
    Validatsiya: karta uniki, sotilishi mumkin, allaqachon e'lon qilinmagan.
    """
    if price_ball <= 0:
        raise ValueError("Narx 0 dan katta bo'lishi kerak")

    ownership = (
        db.query(CardOwnership)
        .filter(
            CardOwnership.id == ownership_id,
            CardOwnership.owner_id == user.id,
        )
        .with_for_update()
        .first()
    )
    if not ownership:
        raise ValueError("Bu karta sizga tegishli emas")
    if not ownership.template.sellable:
        raise ValueError("Bu kartani sotib bo'lmaydi")

    existing = (
        db.query(MarketListing)
        .filter(
            MarketListing.ownership_id == ownership_id,
            MarketListing.status == "active",
        )
        .first()
    )
    if existing:
        raise ValueError("Karta allaqachon e'lon qilingan")

    ai_price = suggest_price(ownership.template, price_ball)
    listing = MarketListing(
        ownership_id=ownership_id,
        seller_id=user.id,
        price_ball=price_ball,
        ai_suggested_price=ai_price,
    )
    db.add(listing)
    db.commit()
    db.refresh(listing)
    return listing


# ── E'LONDAN SOTIB OLISH ─────────────────────────────────────────────────────
def buy_listing(db: Session, buyer: User, listing_id: int) -> MarketListing:
    """
    Bozor e'lonini sotib olish.

    MUHIM xavfsizlik qadamlari:
      - Listing FOR UPDATE bilan qulflanadi → parallel sotib olishlar IMKONSIZ
      - Buyer FOR UPDATE bilan qulflanadi  → balans double-spend IMKONSIZ
      - Seller FOR UPDATE bilan qulflanadi → pul qo'shish ham atomik
      - Barcha o'zgarishlar bitta commit() da
    """
    # 1. Listing'ni LOCK qil — eng muhim qadam
    listing = (
        db.query(MarketListing)
        .filter(
            MarketListing.id == listing_id,
            MarketListing.status == "active",
        )
        .with_for_update()
        .first()
    )
    if not listing:
        raise ValueError("E'lon topilmadi yoki allaqachon sotilgan")
    if listing.seller_id == buyer.id:
        raise ValueError("O'z e'loningizni sotib ololmaysiz")

    # 2. Xaridor qatorini LOCK qil
    locked_buyer = (
        db.query(User)
        .filter(User.id == buyer.id)
        .with_for_update()
        .first()
    )

    # 3. Sotuvchi qatorini LOCK qil
    locked_seller = (
        db.query(User)
        .filter(User.id == listing.seller_id)
        .with_for_update()
        .first()
    )

    price = listing.price_ball
    card_name = listing.ownership.template.name

    # 4. Xaridordan pul ol (balans tekshiruvi change_balance ichida)
    change_balance(db, locked_buyer, "ball", -price, "market_buy", source="user")

    # 5. Sotuvchiga pul ber
    change_balance(db, locked_seller, "ball", price, "market_sell", source="user")

    # 6. Mulkni o'tkazish va listing'ni yopish
    listing.ownership.owner_id = locked_buyer.id
    listing.status  = "sold"
    listing.sold_at = datetime.utcnow()

    db.commit()
    db.refresh(listing)

    # 7. caller uchun buyer ob'ektini yangilash
    db.refresh(buyer)

    # 8. Sotuvchiga bildirishnoma (tranzaksiyadan tashqarida — muvaffaqiyatsiz
    #    bo'lsa ham sotilgan bo'ladi, faqat xabar ketmaydi)
    if locked_seller.notifications_enabled:
        try:
            notify_service.send_telegram(
                locked_seller.telegram_id,
                f"💰 <b>Kartangiz sotildi!</b>\n"
                f"📦 <b>{card_name}</b>\n"
                f"💵 +{price:,} ball qo'shildi\n"
                f"🛒 Xaridor: <b>{buyer.name}</b>",
            )
        except Exception:
            pass  # bildirishnoma muvaffaqiyatsiz bo'lsa sotuvni bekor qilmaymiz

    return listing


# ── E'LONNI BEKOR QILISH ─────────────────────────────────────────────────────
def cancel_listing(db: Session, user: User, listing_id: int) -> MarketListing:
    listing = (
        db.query(MarketListing)
        .filter(
            MarketListing.id == listing_id,
            MarketListing.seller_id == user.id,
            MarketListing.status == "active",
        )
        .with_for_update()
        .first()
    )
    if not listing:
        raise ValueError("E'lon topilmadi")
    listing.status = "cancelled"
    db.commit()
    db.refresh(listing)
    return listing


# ── SOVG'A QILISH ────────────────────────────────────────────────────────────
def gift_card(
    db: Session, sender: User, ownership_id: int, recipient_telegram_id: int
) -> CardOwnership:
    """
    Kartani bir foydalanuvchidan ikkinchisiga sovg'a qilish.
    Karta faol e'londa bo'lmasa va yuboruvchiga tegishli bo'lsa amalga oshadi.
    """
    ownership = (
        db.query(CardOwnership)
        .filter(
            CardOwnership.id == ownership_id,
            CardOwnership.owner_id == sender.id,
        )
        .with_for_update()
        .first()
    )
    if not ownership:
        raise ValueError("Bu karta sizga tegishli emas")
    if not ownership.template.tradeable:
        raise ValueError("Bu kartani sovg'a qilib bo'lmaydi")

    # Faol e'lon bor-yo'qligini tekshir
    active = (
        db.query(MarketListing)
        .filter(
            MarketListing.ownership_id == ownership_id,
            MarketListing.status == "active",
        )
        .first()
    )
    if active:
        raise ValueError("Avval market e'lonini bekor qiling")

    recipient = (
        db.query(User)
        .filter(User.telegram_id == recipient_telegram_id)
        .first()
    )
    if not recipient:
        raise ValueError("Qabul qiluvchi topilmadi — u bot bilan bir marta gaplashishi kerak")
    if recipient.id == sender.id:
        raise ValueError("O'zingizga sovg'a qila olmaysiz")

    ownership.owner_id = recipient.id
    db.commit()
    db.refresh(ownership)

    # Bildirishnoma
    if recipient.notifications_enabled:
        try:
            notify_service.send_telegram(
                recipient.telegram_id,
                f"🎁 <b>{sender.name}</b> sizga karta sovg'a qildi!\n"
                f"📦 <b>{ownership.template.name}</b> ({ownership.template.rarity})\n"
                f"Kolleksiyangizni tekshiring 👇",
            )
        except Exception:
            pass

    return ownership
