"""
Telegram bildirishnoma yuboriш servisi.
Telegram Bot API orqali foydalanuvchilarga real-vaqtli xabar yuboradi.
Fire-and-forget — xatolar jimgina o'tkazib yuboriladi (botni bloklash yoki
token yo'qligi o'yinni to'xtatmasin).
"""
import requests

from app.core.config import settings


def send_telegram(telegram_id: int, text: str) -> None:
    """
    telegram_id ga HTML formatdagi text xabarini yuboradi.
    notifications_enabled tekshiruvi chaqiruvchi tomonda amalga oshiriladi.
    """
    if not settings.BOT_TOKEN or not telegram_id:
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{settings.BOT_TOKEN}/sendMessage",
            json={
                "chat_id": telegram_id,
                "text": text,
                "parse_mode": "HTML",
            },
            timeout=5,
        )
    except Exception:
        # Tarmoq xatosi yoki bot bloklanishi — jim o'tamiz
        pass
