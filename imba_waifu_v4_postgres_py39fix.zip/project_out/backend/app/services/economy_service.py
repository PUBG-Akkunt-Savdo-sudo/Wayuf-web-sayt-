"""
economy_service.py — Balans o'zgartirishlarining YAGONA nuqtasi.

Qoidalar:
  1. Balans HECH QACHON frontenddan qabul qilinmaydi
  2. Har bir o'zgarish Transaction jadvali orqali loglanadi
  3. Balans manfiy bo'lishiga yo'l qo'yilmaydi
  4. Caller oldin user qatorini with_for_update() bilan qulflashi kerak
     (market_service va boshqalar shuni qiladi)
"""
from sqlalchemy.orm import Session

from app.models.user import User
from app.models.transaction import Transaction

RANK_THRESHOLDS = [
    (1,   "Newbie"),
    (10,  "Rookie"),
    (20,  "Fighter"),
    (30,  "Elite"),
    (40,  "Pro Gamer"),
    (50,  "Master"),
    (70,  "Legend"),
    (100, "Mythic"),
]

DAILY_LIMITS = {
    "ball":    10_000_000,   # kuniga 10M dan ko'p olinsa shubhali
    "diamond": 100_000,
    "keys":    1_000,
    "xp":      500_000,
    "achko":   10_000,
}


def rank_title_for_level(level: int) -> str:
    title = RANK_THRESHOLDS[0][1]
    for min_level, name in RANK_THRESHOLDS:
        if level >= min_level:
            title = name
        else:
            break
    return title


def change_balance(
    db: Session,
    user: User,
    currency: str,
    amount: int,
    tx_type: str,
    source: str = "system",
) -> User:
    """
    Foydalanuvchi balansini xavfsiz o'zgartirish.

    currency : 'ball' | 'diamond' | 'keys' | 'xp' | 'achko'
    amount   : musbat — qo'shish, manfiy — ayirish
    tx_type  : 'shop_buy', 'market_buy', 'market_sell', 'chest_open', ...
    source   : 'user' | 'system' | 'admin'

    ValueError:
      - Noto'g'ri valyuta
      - Yetarli mablag' yo'q
      - Admin bo'lmagan holda amount haddan tashqari katta (anti-cheat)
    """
    allowed = {"ball", "diamond", "keys", "xp", "achko"}
    if currency not in allowed:
        raise ValueError(f"Noto'g'ri valyuta: {currency}")

    if amount == 0:
        return user

    # Anti-cheat: user so'rovi bo'lsa va miqdor limit'dan oshsa — rad et
    if source == "user" and abs(amount) > DAILY_LIMITS.get(currency, 10_000_000):
        raise ValueError(f"Bir operatsiyada haddan tashqari ko'p {currency}")

    before = getattr(user, currency, 0)
    after  = before + amount

    if after < 0:
        raise ValueError(
            f"Yetarli {currency} yo'q: mavjud {before:,}, kerak {-amount:,}"
        )

    setattr(user, currency, after)

    db.add(Transaction(
        user_id        = user.id,
        type           = tx_type,
        currency       = currency,
        amount         = amount,
        before_balance = before,
        after_balance  = after,
        source         = source,
    ))
    db.commit()
    db.refresh(user)
    return user


def add_xp(db: Session, user: User, amount: int) -> User:
    """
    XP qo'shish va zarur bo'lsa darajani oshirish.
    Darajalar orasidagi chegara: har yangi darajada 1.35x o'sadi.
    """
    if amount <= 0:
        return user

    user.xp += amount
    leveled_up = False

    while user.xp >= user.xp_next:
        user.xp    -= user.xp_next
        user.level += 1
        user.xp_next = max(100, int(user.xp_next * 1.35))
        leveled_up   = True

    if leveled_up:
        user.rank_title = rank_title_for_level(user.level)
        # achko ham berish (rank-based reward)
        achko_bonus = user.level * 50
        user.achko = (user.achko or 0) + achko_bonus

    db.commit()
    db.refresh(user)
    return user


def admin_adjust_balance(
    db: Session,
    user: User,
    currency: str,
    amount: int,
    admin_user: User,
) -> User:
    """
    Admin tomonidan balans o'zgartirish — DAILY_LIMITS qo'llanilmaydi.
    Barcha admin o'zgarishlari 'admin' source bilan loglanadi.
    """
    allowed = {"ball", "diamond", "keys", "xp", "achko"}
    if currency not in allowed:
        raise ValueError(f"Noto'g'ri valyuta: {currency}")

    before = getattr(user, currency, 0)
    after  = max(0, before + amount)   # admin ayirishda manfiy qilolmaydi

    setattr(user, currency, after)

    db.add(Transaction(
        user_id        = user.id,
        type           = "admin_adjust",
        currency       = currency,
        amount         = after - before,    # haqiqiy o'zgarish
        before_balance = before,
        after_balance  = after,
        source         = "admin",
        note           = f"admin:{admin_user.id}",
    ))
    db.commit()
    db.refresh(user)
    return user
