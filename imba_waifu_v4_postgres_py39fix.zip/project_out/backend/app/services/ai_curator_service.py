"""
Daily AI curation — two independent jobs, both meant to be run once a day
by the scheduler in main.py (not on every request, so these take a plain
db session rather than being FastAPI dependencies):

1. generate_daily_cards() — adds 5 new anime cards/day (Gemini suggests the
   character, Gemini generates the art).
2. prune_unpopular_cards() — removes cards that are NOT Galaxy/Special/Unique,
   have existed for 3+ months, and still have 2 or fewer distinct owners.
   Galaxy/Special/Unique are never touched, no matter how few people own them.
"""
import base64
import logging
import random
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.admin_setting import AdminSetting
from app.models.card import CardTemplate, CardOwnership, MarketListing
from ai_engine.provider_router import generate_card_image, suggest_anime_characters, RARITY_MULTIPLIER

logger = logging.getLogger("ai_curator")

PRUNABLE_RARITIES = {"Ordinary"}  # only this tier is ever auto-deleted; every other tier is protected
PRUNE_AGE_DAYS = 90
PRUNE_MAX_OWNERS = 2
DAILY_CARD_COUNT = 5


def _get_setting(db: Session, key: str) -> Optional[str]:
    row = db.query(AdminSetting).filter(AdminSetting.key == key).first()
    return row.value if row else None


def _pick_rarity() -> str:
    """Same odds as chest drops (Unique is never auto-created here, matching
    the spec's rule that Unique cards never drop — they stay admin-only)."""
    weights = settings.RARITY_WEIGHTS
    return random.choices(list(weights.keys()), weights=list(weights.values()), k=1)[0]


def generate_daily_cards(db: Session, count: int = DAILY_CARD_COUNT) -> list[CardTemplate]:
    """
    Adds `count` new AI-curated anime cards for today. Skips (logs a warning,
    returns []) if no Gemini key is configured in Admin Panel -> Settings —
    this runs unattended, so it must never raise and break the scheduler.
    """
    api_key = _get_setting(db, "gemini_api_key")
    if not api_key:
        logger.warning("daily AI card generation skipped: gemini_api_key not configured")
        return []

    existing_names = {c.name for (c,) in db.query(CardTemplate.name).all()}
    suggestions = suggest_anime_characters(api_key, count=count, exclude=existing_names)

    today = datetime.utcnow().strftime("%Y%m%d")
    created = []
    for i, s in enumerate(suggestions[:count], start=1):
        code = f"AI-{today}-{i}"
        if db.query(CardTemplate).filter(CardTemplate.code == code).first():
            continue  # scheduler already ran today — don't double-post

        rarity = _pick_rarity()
        image_url = ""
        try:
            prompt = (
                f"A high-quality anime trading-card style portrait illustration of a character named "
                f"'{s['name']}'" + (f" from the series '{s['anime']}'" if s.get("anime") else "") +
                f". Rarity tier: {rarity}. Vertical card composition, dramatic lighting, detailed "
                f"line art, vibrant colors matching a {rarity.lower()}-tier fantasy card game aesthetic."
            )
            image_bytes, mime = generate_card_image(prompt, api_key)
            image_url = f"data:{mime};base64,{base64.b64encode(image_bytes).decode()}"
        except RuntimeError as e:
            logger.error(f"daily AI card generation: image failed for {s['name']}: {e}")
            # keep going with image_url="" — frontend shows placeholder art instead of skipping the card

        card = CardTemplate(
            code=code, name=s["name"], anime=s.get("anime", ""), rarity=rarity,
            image_url=image_url,
            base_price_ball=int(1000 * RARITY_MULTIPLIER.get(rarity, 1.0)),
            chest_drop=True, is_limited=False, visibility_rule="public",
        )
        db.add(card)
        created.append(card)

    if created:
        db.commit()
        for c in created:
            db.refresh(c)
    logger.info(f"daily AI card generation: added {len(created)} cards")
    return created


def prune_unpopular_cards(db: Session, dry_run: bool = False) -> list[dict]:
    """
    Deletes card templates that:
      - are Ordinary rarity (the ONLY tier this ever touches — Rare, Special,
        Legend, Galaxy and Unique are all protected regardless of ownership)
      - were created at least PRUNE_AGE_DAYS (90) days ago — new cards get a
        grace period before they're judged on adoption
      - have PRUNE_MAX_OWNERS (2) or fewer *distinct* current owners

    Deleting a template cascades to its market listings and ownerships — any
    copies still held by those <=2 owners are removed from their collections
    too, since the card is being retired from the game entirely.

    dry_run=True computes and returns the same list without deleting
    anything — useful to preview from the admin panel before it runs live.
    """
    cutoff = datetime.utcnow() - timedelta(days=PRUNE_AGE_DAYS)
    candidates = db.query(CardTemplate).filter(
        CardTemplate.rarity.in_(PRUNABLE_RARITIES),
        CardTemplate.created_at <= cutoff,
    ).all()

    removed = []
    for card in candidates:
        owner_count = (
            db.query(func.count(func.distinct(CardOwnership.owner_id)))
            .filter(CardOwnership.template_id == card.id)
            .scalar()
        )
        if owner_count > PRUNE_MAX_OWNERS:
            continue

        removed.append({
            "id": card.id, "code": card.code, "name": card.name,
            "rarity": card.rarity, "owners": owner_count,
        })
        if dry_run:
            continue

        ownership_ids = [
            oid for (oid,) in db.query(CardOwnership.id).filter(CardOwnership.template_id == card.id).all()
        ]
        if ownership_ids:
            db.query(MarketListing).filter(MarketListing.ownership_id.in_(ownership_ids)) \
                .delete(synchronize_session=False)
            db.query(CardOwnership).filter(CardOwnership.template_id == card.id) \
                .delete(synchronize_session=False)
        db.delete(card)

    if not dry_run and removed:
        db.commit()
    logger.info(f"card prune: {'would remove' if dry_run else 'removed'} {len(removed)} cards")
    return removed
