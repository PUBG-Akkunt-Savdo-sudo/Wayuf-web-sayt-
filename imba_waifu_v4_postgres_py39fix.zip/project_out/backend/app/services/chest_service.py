import random
from datetime import datetime

from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.card import CardTemplate, CardOwnership
from app.models.user import User
from app.services.economy_service import change_balance, add_xp
from app.services import drop_service


def open_chest(db: Session, user: User) -> CardTemplate:
    """
    Spends 1 key, picks a random card weighted by rarity (Unique never drops
    — spec: 'Unique karta Open Chest'dan tushmaydi'). Limited-rotation cards
    (is_limited=True) only enter the pool while their FeaturedDrop window
    is active — same PUBG/DLS-style rotation rule as the shop.
    """
    if user.keys < 1:
        raise ValueError("no keys left")

    drop_service.resolve_expired_drops(db)
    active_ids = drop_service.active_card_ids(db)

    pool = db.query(CardTemplate).filter(
        CardTemplate.chest_drop.is_(True),
        CardTemplate.rarity != "Unique",
    ).all()
    pool = [c for c in pool if not c.is_limited or c.id in active_ids]
    if not pool:
        raise ValueError("no cards available to drop")

    weights = [settings.RARITY_WEIGHTS.get(c.rarity, 1) for c in pool]
    won = random.choices(pool, weights=weights, k=1)[0]

    change_balance(db, user, "keys", -1, "chest_open", source="user")
    db.add(CardOwnership(template_id=won.id, owner_id=user.id))
    user.chest_claimed_at = datetime.utcnow()
    db.commit()

    add_xp(db, user, settings.CHEST_OPEN_XP)
    return won
