"""
Limited-time card rotation, like PUBG/DLS's rotating rare weapons/skins.

Honesty note: `resolve_expired_drops` uses a fixed probability, not a real
AI model. It's called "avtomatik tizim" (automatic system) in the frontend,
never "AI", so nobody is misled about what's actually deciding this.
"""
import random
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from app.models.card import CardTemplate
from app.models.featured_drop import FeaturedDrop

RETURN_CHANCE = 0.35  # 35% chance a retired-window card comes back for another round


def create_drop(db: Session, card_template_id: int, hours: int = 24, admin_id: Optional[int] = None) -> FeaturedDrop:
    card = db.query(CardTemplate).filter(CardTemplate.id == card_template_id).first()
    if not card:
        raise ValueError("card not found")

    existing = db.query(FeaturedDrop).filter(
        FeaturedDrop.card_template_id == card_template_id, FeaturedDrop.status == "active"
    ).first()
    if existing:
        raise ValueError("this card already has an active drop window")

    card.is_limited = True
    drop = FeaturedDrop(
        card_template_id=card_template_id,
        starts_at=datetime.utcnow(),
        ends_at=datetime.utcnow() + timedelta(hours=hours),
        status="active",
        created_by_admin_id=admin_id,
    )
    db.add(drop)
    db.commit()
    db.refresh(drop)
    return drop


def resolve_expired_drops(db: Session) -> list[FeaturedDrop]:
    """
    Called opportunistically (shop/chest endpoints call this before serving
    results) so no cron/scheduler process is required. Any 'active' drop
    whose window has passed gets auto-decided: comes back for another
    round, or retires until an admin manually re-features it.
    """
    now = datetime.utcnow()
    expired = db.query(FeaturedDrop).filter(FeaturedDrop.status == "active", FeaturedDrop.ends_at <= now).all()
    resolved = []
    for drop in expired:
        returns = random.random() < RETURN_CHANCE
        drop.status = "returning" if returns else "retired"
        drop.auto_decided = True
        drop.resolved_at = now
        if returns:
            new_drop = FeaturedDrop(
                card_template_id=drop.card_template_id,
                starts_at=now,
                ends_at=now + (drop.ends_at - drop.starts_at),  # same duration as before
                status="active",
            )
            db.add(new_drop)
        else:
            drop.card.is_limited = True  # stays limited (just inactive) — admin must re-feature to bring back
        resolved.append(drop)
    if expired:
        db.commit()
    return resolved


def resolve_drop_manually(db: Session, drop_id: int, decision: str) -> FeaturedDrop:
    """Admin override — decision is 'return' or 'retire', skips the probability roll."""
    drop = db.query(FeaturedDrop).filter(FeaturedDrop.id == drop_id).first()
    if not drop:
        raise ValueError("drop not found")
    if drop.status != "active":
        raise ValueError("drop is not active")

    now = datetime.utcnow()
    if decision == "return":
        drop.status = "returning"
        new_drop = FeaturedDrop(
            card_template_id=drop.card_template_id, starts_at=now,
            ends_at=now + (drop.ends_at - drop.starts_at), status="active",
        )
        db.add(new_drop)
    elif decision == "retire":
        drop.status = "retired"
    else:
        raise ValueError("decision must be 'return' or 'retire'")

    drop.resolved_at = now
    drop.auto_decided = False
    db.commit()
    return drop


def active_card_ids(db: Session) -> set[int]:
    """card_template_ids that currently have an active (unexpired) drop window."""
    now = datetime.utcnow()
    rows = db.query(FeaturedDrop.card_template_id).filter(
        FeaturedDrop.status == "active", FeaturedDrop.ends_at > now
    ).all()
    return {r[0] for r in rows}
