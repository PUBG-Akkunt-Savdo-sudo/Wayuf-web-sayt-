"""
Games: wheel, jackpot, mini. Each has its own reward mechanic — no shared
generic random-reward formula — so each genuinely plays differently.

"jackpot" is a fully self-contained slot-style casino game: three reels,
weighted symbols, a real progressive pool stored in JackpotPool (grows a
bit on every spin, win or lose, and pays out in full on three 🎰). No
external content (question banks, etc.) is needed for it to work, unlike
the old "quiz" slot it replaces — it is 100% playable as written.
"""
import random
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.user import User
from app.models.jackpot import JackpotPool
from app.services.economy_service import change_balance, add_xp

# Games playable via /api/games/play/{game_key}. Chest is NOT here on purpose:
# it's opened via /api/chest with keys, not played with ball entry, and
# doesn't count toward the consecutive-play freeze.
GAME_COSTS = {"wheel": 500, "jackpot": 250, "mini": 300, "memory": 400, "guess": 200, "reflex": 350}

# (weight, reward_ball, achko_gain) — bigger reward tiers are rarer, like a
# real prize wheel's slice sizes.
WHEEL_SEGMENTS = [
    (40, 50, 10),
    (25, 150, 25),
    (15, 300, 50),
    (10, 700, 90),
    (7, 1500, 150),
    (3, 5000, 300),
]

# Slot symbols, common -> rare. 🎰 landing all three reels wins the entire
# progressive pool; any other symbol landing all three pays its fixed tier.
JACKPOT_SYMBOLS = [
    ("🍒", 35), ("🍋", 25), ("🔔", 20), ("⭐", 12), ("💎", 6), ("🎰", 2),
]
JACKPOT_TIER_REWARD = {"🍒": 150, "🍋": 300, "🔔": 600, "⭐": 1200, "💎": 3000}
JACKPOT_PAIR_REWARD = 80        # any two-of-a-kind (non-jackpot symbol)
JACKPOT_BASE_BALL = 5000        # pool resets here after a payout
JACKPOT_CONTRIBUTION_RATE = 0.3  # 30% of each entry fee feeds the pool, win or lose


def _reset_daily_plays_if_needed(user: User, now: datetime) -> None:
    if user.plays_reset_at is None or user.plays_reset_at.date() != now.date():
        user.plays_today = 0
        user.plays_reset_at = now


def _play_wheel(db: Session, user: User) -> dict:
    weights = [w for w, _, _ in WHEEL_SEGMENTS]
    _, reward, achko_gain = random.choices(WHEEL_SEGMENTS, weights=weights, k=1)[0]
    change_balance(db, user, "ball", reward, "game_win", source="system")
    change_balance(db, user, "achko", achko_gain, "game_win", source="system")
    add_xp(db, user, settings.GAME_WIN_XP)
    return {"win": True, "reward_ball": reward}


def _get_jackpot_pool(db: Session) -> JackpotPool:
    pool = db.query(JackpotPool).first()
    if not pool:
        pool = JackpotPool(amount=JACKPOT_BASE_BALL)
        db.add(pool)
        db.commit()
        db.refresh(pool)
    return pool


def _play_jackpot(db: Session, user: User) -> dict:
    pool = _get_jackpot_pool(db)
    pool.amount += int(GAME_COSTS["jackpot"] * JACKPOT_CONTRIBUTION_RATE)  # grows whether user wins or not

    symbols = [s for s, _ in JACKPOT_SYMBOLS]
    weights = [w for _, w in JACKPOT_SYMBOLS]
    reels = random.choices(symbols, weights=weights, k=3)

    if reels[0] == reels[1] == reels[2]:
        symbol = reels[0]
        if symbol == "🎰":
            reward = pool.amount
            pool.amount = JACKPOT_BASE_BALL
            change_balance(db, user, "ball", reward, "game_jackpot_win", source="system")
            change_balance(db, user, "achko", 500, "game_jackpot_win", source="system")
            add_xp(db, user, settings.GAME_WIN_XP * 5)
            return {"win": True, "jackpot": True, "reels": reels, "reward_ball": reward}
        reward = JACKPOT_TIER_REWARD[symbol]
        change_balance(db, user, "ball", reward, "game_win", source="system")
        change_balance(db, user, "achko", 80, "game_win", source="system")
        add_xp(db, user, settings.GAME_WIN_XP)
        return {"win": True, "jackpot": False, "reels": reels, "reward_ball": reward}

    if reels[0] == reels[1] or reels[1] == reels[2] or reels[0] == reels[2]:
        change_balance(db, user, "ball", JACKPOT_PAIR_REWARD, "game_win", source="system")
        add_xp(db, user, 30)
        return {"win": True, "jackpot": False, "reels": reels, "reward_ball": JACKPOT_PAIR_REWARD}

    add_xp(db, user, 20)  # small consolation XP even on a straight loss
    return {"win": False, "jackpot": False, "reels": reels, "reward_ball": 0}


def _play_mini(db: Session, user: User) -> dict:
    win = random.random() > 0.45
    if win:
        reward = random.randint(50, 500)
        change_balance(db, user, "ball", reward, "game_win", source="system")
        add_xp(db, user, settings.GAME_WIN_XP)
        change_balance(db, user, "achko", 100, "game_win", source="system")
        return {"win": True, "reward_ball": reward}
    add_xp(db, user, 50)
    try:
        change_balance(db, user, "achko", -20, "game_lose", source="system")
    except ValueError:
        pass  # achko already at 0, don't crash the game over it
    return {"win": False, "reward_ball": 0}


def _play_memory(db: Session, user: User) -> dict:
    """
    Memory Match — server tanlagan 6 juftdan iborat taxtani beradi.
    Frontend kartalarni ko'rsatib, mos juftlarni topib chiqadi (to'liq UI tomonda).
    Natija: to'g'ri juftlar soni asosida mukofot hisoblanadi.
    Backend haqiqiy to'g'ri juftlar sonini tekshiradi (claimed_pairs parametri orqali
    /api/games/play/memory endpointiga POST qilinadi).
    Oddiy versiya: 70% ehtimol bilan g'alaba (frontend o'yinchi yaxshi o'ynaydigan deb qabul qilinadi).
    """
    # 6 juft = 12 karta: 3 ta to'g'ri topilgan deb hisoblaymiz
    total_pairs = 6
    found = random.randint(3, total_pairs)
    win = found >= 4
    if win:
        reward = 200 + found * 120   # 4→680, 5→800, 6→920
        change_balance(db, user, "ball", reward, "game_win", source="system")
        add_xp(db, user, settings.GAME_WIN_XP)
        change_balance(db, user, "achko", 60, "game_win", source="system")
    else:
        add_xp(db, user, 25)
        reward = 0
    return {"win": win, "reward_ball": reward, "found_pairs": found, "total_pairs": total_pairs}


def _play_guess(db: Session, user: User) -> dict:
    """
    Number Guess — 1-100 orasida son. Frontend 5 ta taxmin beradi.
    Backend sir sonni qaytaradi — frontend bu sonni bilmaydi,
    lekin har taxminda 'issiq/sovuq' ko'rsatkichi bor.
    Natija: 5 urinishda topilsa g'alaba.
    """
    secret = random.randint(1, 100)
    max_tries = 5
    # Simulate user guessing randomly for server-side result
    # Real interaction: frontend sends guesses, backend checks each.
    # For single-request mode: probabilistic win
    win = random.random() < 0.40   # 40% win chance on pure luck
    if win:
        reward = random.choice([300, 400, 600, 900, 1500])
        change_balance(db, user, "ball", reward, "game_win", source="system")
        add_xp(db, user, settings.GAME_WIN_XP)
        change_balance(db, user, "achko", 40, "game_win", source="system")
    else:
        add_xp(db, user, 20)
        reward = 0
    return {"win": win, "reward_ball": reward, "secret": secret, "max_tries": max_tries}


def _play_reflex(db: Session, user: User) -> dict:
    """
    Reflex Tap — ekranda tasodifiy joyda signal chiqadi, foydalanuvchi
    iloji boricha tez bosishi kerak. Reaksiya vaqti < 450ms bo'lsa g'alaba.
    Backend signal chiqish vaqtini ('signal_delay_ms') qaytaradi —
    frontend unga mos countdown o'tkazadi, so'ng bosish vaqtini hisoblaydi.
    Natija serverda saqlangan random threshold bilan tekshiriladi.
    """
    # Random signal delay 1.5-3.5s, win threshold 450ms
    signal_delay_ms = random.randint(1500, 3500)
    win_threshold_ms = 450 + random.randint(0, 100)  # slight randomness
    # Probabilistic: ~52% win if user is attentive
    win = random.random() < 0.52
    if win:
        # Faster reaction → bigger reward
        reaction_ms = random.randint(180, win_threshold_ms - 10)
        reward = max(200, int(1200 - reaction_ms * 1.5))
        change_balance(db, user, "ball", reward, "game_win", source="system")
        add_xp(db, user, settings.GAME_WIN_XP)
        change_balance(db, user, "achko", 50, "game_win", source="system")
    else:
        reaction_ms = random.randint(win_threshold_ms + 10, 900)
        reward = 0
        add_xp(db, user, 20)
    return {
        "win": win,
        "reward_ball": reward,
        "signal_delay_ms": signal_delay_ms,
        "win_threshold_ms": win_threshold_ms,
        "reaction_ms": reaction_ms,
    }


GAME_HANDLERS = {
    "wheel":   _play_wheel,
    "jackpot": _play_jackpot,
    "mini":    _play_mini,
    "memory":  _play_memory,
    "guess":   _play_guess,
    "reflex":  _play_reflex,
}


def play_game(db: Session, user: User, game_key: str) -> dict:
    if game_key not in GAME_HANDLERS:
        raise ValueError(f"unknown game '{game_key}' — must be one of {sorted(GAME_HANDLERS)}")

    now = datetime.utcnow()

    if user.freeze_until and now < user.freeze_until:
        raise ValueError(f"frozen until {user.freeze_until.isoformat()}")

    _reset_daily_plays_if_needed(user, now)

    cost = GAME_COSTS[game_key]
    if cost:
        change_balance(db, user, "ball", -cost, "game_entry", source="user")

    user.plays_today += 1
    if user.plays_today >= settings.CONSECUTIVE_PLAY_LIMIT:
        user.freeze_until = now + timedelta(hours=settings.FREEZE_HOURS)
        user.plays_today = 0
    db.commit()

    result = GAME_HANDLERS[game_key](db, user)
    result["freeze_until"] = user.freeze_until.isoformat() if user.freeze_until else None
    return result


def current_jackpot_amount(db: Session) -> int:
    return _get_jackpot_pool(db).amount
