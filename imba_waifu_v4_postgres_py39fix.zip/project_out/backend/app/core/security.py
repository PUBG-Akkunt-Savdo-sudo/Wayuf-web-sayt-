"""
Verifies Telegram Mini App `initData` so we can trust who the request is
really coming from. Without this, anyone could pretend to be any user_id
and steal balances/cards.

Docs: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
"""
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from fastapi import Header, HTTPException, Depends
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.models.user import User

MAX_INIT_DATA_AGE_SECONDS = 86400  # 24h — reject stale/replayed initData


def verify_init_data(init_data: str, bot_token: str) -> dict:
    """Returns the parsed user dict if valid, raises ValueError otherwise."""
    if not init_data:
        raise ValueError("empty init_data")

    parsed = dict(parse_qsl(init_data, strict_parsing=True))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise ValueError("missing hash")

    auth_date = parsed.get("auth_date")
    if auth_date and (time.time() - int(auth_date)) > MAX_INIT_DATA_AGE_SECONDS:
        raise ValueError("init_data expired")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    computed_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(computed_hash, received_hash):
        raise ValueError("hash mismatch — data not from Telegram")

    user_json = parsed.get("user")
    if not user_json:
        raise ValueError("no user in init_data")
    return json.loads(user_json)


def get_current_user(
    x_telegram_init_data: str = Header(..., alias="X-Telegram-Init-Data"),
    db: Session = Depends(get_db),
) -> User:
    """
    FastAPI dependency used on every protected endpoint. Validates the
    Telegram initData header, then fetches (or creates) the matching User row.
    """
    if not settings.BOT_TOKEN:
        raise HTTPException(500, "Server misconfigured: BOT_TOKEN not set")

    try:
        tg_user = verify_init_data(x_telegram_init_data, settings.BOT_TOKEN)
    except ValueError as e:
        raise HTTPException(401, f"Invalid Telegram auth: {e}")

    telegram_id = tg_user["id"]
    user = db.query(User).filter(User.telegram_id == telegram_id).first()
    if not user:
        user = User(
            telegram_id=telegram_id,
            name=tg_user.get("first_name", "Waifu Collector"),
            is_admin=(telegram_id == settings.OWNER_TELEGRAM_ID),
        )
        db.add(user)
        db.commit()
        db.refresh(user)
    elif telegram_id == settings.OWNER_TELEGRAM_ID and not user.is_admin:
        user.is_admin = True
        db.commit()
        db.refresh(user)

    if user.banned:
        raise HTTPException(403, "your account has been banned")
    return user


def get_current_admin(user: User = Depends(get_current_user)) -> User:
    """Stricter dependency for /api/admin/* routes — 403s anyone who isn't an admin."""
    if not user.is_admin:
        raise HTTPException(403, "admin access required")
    return user
