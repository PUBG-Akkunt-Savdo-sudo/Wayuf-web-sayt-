"""
config.py — Barcha sozlamalar .env faylidan o'qiladi.
Production'da hech qachon default qiymatlarni ishlatmang.
"""
import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()


def _require(key: str) -> str:
    """Muhim o'zgaruvchi yo'q bo'lsa — darhol to'xtatish."""
    val = os.getenv(key, "")
    if not val:
        raise RuntimeError(
            f"❌ Muhim sozlama topilmadi: {key}\n"
            f"   .env faylini tekshiring yoki environment variable qiling."
        )
    return val


class Settings:
    # ── Majburiy ──────────────────────────────────────────────────────────
    BOT_TOKEN:          str = _require("BOT_TOKEN")
    DATABASE_URL:       str = _require("DATABASE_URL")
    OWNER_TELEGRAM_ID:  int = int(_require("OWNER_TELEGRAM_ID"))

    # ── Ixtiyoriy ─────────────────────────────────────────────────────────
    MINIAPP_URL:   str       = os.getenv("MINIAPP_URL", "")
    CORS_ORIGINS:  list[str] = os.getenv("CORS_ORIGINS", "*").split(",")
    GEMINI_API_KEY: Optional[str] = os.getenv("GEMINI_API_KEY")

    # ── Iqtisodiyot konstantalari ─────────────────────────────────────────
    DAILY_BONUS_BALL:       int = int(os.getenv("DAILY_BONUS_BALL", "2000"))
    DAILY_BONUS_XP:         int = int(os.getenv("DAILY_BONUS_XP",   "100"))
    CHEST_OPEN_XP:          int = int(os.getenv("CHEST_OPEN_XP",    "150"))
    GAME_WIN_XP:            int = int(os.getenv("GAME_WIN_XP",       "40"))

    # ── O'yin cheklovlari ─────────────────────────────────────────────────
    CONSECUTIVE_PLAY_LIMIT: int = int(os.getenv("CONSECUTIVE_PLAY_LIMIT", "6"))
    FREEZE_HOURS:           int = int(os.getenv("FREEZE_HOURS", "6"))

    # ── Sandiq rarity og'irliklari ────────────────────────────────────────
    RARITY_WEIGHTS: dict[str, int] = {
        "Ordinary": 45,
        "Rare":     28,
        "Special":  15,
        "Legend":    8,
        "Galaxy":    4,
        # Unique — sandiqdan tushishi spec'da taqiqlangan
    }


settings = Settings()
