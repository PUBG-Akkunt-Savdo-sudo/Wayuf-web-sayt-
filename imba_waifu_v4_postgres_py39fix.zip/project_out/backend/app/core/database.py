"""
database.py — PostgreSQL bilan ishlaydigan DB qatlami.

SQLite'dan farqi:
  - Connection pool (QueuePool) — parallel so'rovlar xavfsiz
  - pool_pre_ping — uzilib qolgan ulanishlarni avtomatik qayta tiklaydi
  - WITH FOR UPDATE — market_service da ishlatiladi (SQLite'da ishlamagan)
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import QueuePool

from app.core.config import settings

# ── Engine ──────────────────────────────────────────────────────────────────
_is_sqlite = settings.DATABASE_URL.startswith("sqlite")

if _is_sqlite:
    # Faqat local dev/test uchun — production'da ishlatmang
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False},
        echo=False,
    )
else:
    # PostgreSQL — production sozlamalari
    engine = create_engine(
        settings.DATABASE_URL,
        poolclass=QueuePool,
        pool_size=10,           # doimiy ochiq ulanishlar
        max_overflow=20,        # yuklanish paytida qo'shimcha
        pool_timeout=30,        # ulanish kutish vaqti (s)
        pool_recycle=1800,      # 30 daqiqada ulanishni yangilash
        pool_pre_ping=True,     # uzilib qolgan ulanishlarni tekshirish
        echo=False,
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency: DB sessiyasini beradi va doim yopadi."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Barcha jadvallarni yaratish. Startup'da bir marta chaqiriladi."""
    from app.models import (  # noqa: F401
        user, card, transaction, chat,
        admin_setting, featured_drop, jackpot,
    )
    Base.metadata.create_all(bind=engine)
    print("✅ DB jadvallari yaratildi/tekshirildi")
