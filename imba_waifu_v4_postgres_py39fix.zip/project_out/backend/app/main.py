import os
import sys

# ai_engine/ lives one level above backend/ (project root) — make it importable
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import init_db, SessionLocal
from app.api import users, cards, market, chest, games, chat, admin
from app.services import ai_curator_service

app = FastAPI(title="IMBA WAIFU API")
scheduler = AsyncIOScheduler()

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(users.router)
app.include_router(cards.router)
app.include_router(market.router)
app.include_router(chest.router)
app.include_router(games.router)
app.include_router(chat.router)
app.include_router(admin.router)


def _run_daily_ai_jobs():
    """
    Runs in the scheduler's own thread with its own DB session (not the
    per-request get_db) since no HTTP request is involved.
    Note (Termux): this only fires while the backend process is actually
    running at the scheduled hour — if you stop uvicorn overnight, that
    day's run is skipped, it won't "catch up" later.
    """
    db = SessionLocal()
    try:
        ai_curator_service.generate_daily_cards(db)
        ai_curator_service.prune_unpopular_cards(db)
    finally:
        db.close()


@app.on_event("startup")
def on_startup():
    init_db()
    scheduler.add_job(_run_daily_ai_jobs, "cron", hour=3, minute=0, id="daily_ai_curator", replace_existing=True)
    scheduler.start()


@app.get("/api/health")
def health():
    return {"status": "ok"}
