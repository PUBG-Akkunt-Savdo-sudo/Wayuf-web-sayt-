from datetime import datetime

from sqlalchemy import Column, Integer, BigInteger, String, Boolean, DateTime, JSON
from sqlalchemy.orm import relationship

from app.core.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    telegram_id = Column(BigInteger, unique=True, index=True, nullable=False)
    name = Column(String, default="Waifu Collector")
    avatar_url = Column(String, default="")
    vip = Column(Boolean, default=False)
    is_admin = Column(Boolean, default=False)
    banned = Column(Boolean, default=False)
    notifications_enabled = Column(Boolean, default=True)

    level = Column(Integer, default=1)
    xp = Column(Integer, default=0)
    xp_next = Column(Integer, default=1000)
    rank_title = Column(String, default="Newbie")

    diamond = Column(Integer, default=0)     # premium currency (top-up)
    ball = Column(Integer, default=5000)     # spendable internal currency
    achko = Column(Integer, default=0)       # ranking/competitive score
    keys = Column(Integer, default=1)        # chest-opening resource

    daily_claimed_at = Column(DateTime, nullable=True)
    chest_claimed_at = Column(DateTime, nullable=True)
    missions_done = Column(JSON, default=list)     # mission ids done today
    missions_reset_at = Column(DateTime, default=datetime.utcnow)

    plays_today = Column(Integer, default=0)
    plays_reset_at = Column(DateTime, default=datetime.utcnow)  # last UTC day plays_today was zeroed
    freeze_until = Column(DateTime, nullable=True)  # 10x-play freeze (spec: 6h)

    created_at = Column(DateTime, default=datetime.utcnow)

    cards = relationship("CardOwnership", back_populates="owner")
    transactions = relationship("Transaction", back_populates="user")

    def public_dict(self):
        return {
            "id": self.id,
            "telegram_id": self.telegram_id,
            "name": self.name,
            "avatar_url": self.avatar_url,
            "vip": self.vip,
            "is_admin": self.is_admin,
            "banned": self.banned,
            "notifications_enabled": self.notifications_enabled,
            "level": self.level,
            "xp": self.xp,
            "xp_next": self.xp_next,
            "rank_title": self.rank_title,
            "diamond": self.diamond,
            "ball": self.ball,
            "achko": self.achko,
            "keys": self.keys,
            "daily_claimed_at": self.daily_claimed_at.isoformat() if self.daily_claimed_at else None,
            "chest_claimed_at": self.chest_claimed_at.isoformat() if self.chest_claimed_at else None,
            "missions_done": self.missions_done or [],
            "freeze_until": self.freeze_until.isoformat() if self.freeze_until else None,
        }
