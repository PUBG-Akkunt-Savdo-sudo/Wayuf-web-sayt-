from datetime import datetime

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Float
from sqlalchemy.orm import relationship

from app.core.database import Base

RARITIES = ["Ordinary", "Rare", "Special", "Legend", "Galaxy", "Unique"]


class CardTemplate(Base):
    """The 'design' of a card — e.g. 'Galaxy Emilia'. Many users can own copies."""
    __tablename__ = "card_templates"

    id = Column(Integer, primary_key=True)
    code = Column(String, unique=True, index=True)      # e.g. "GX-01"
    name = Column(String, nullable=False)
    anime = Column(String, default="")
    rarity = Column(String, default="Ordinary")
    image_url = Column(String, default="")               # empty -> frontend uses placeholder art

    base_price_diamond = Column(Integer, default=0)
    base_price_ball = Column(Integer, default=1000)

    tradeable = Column(Boolean, default=True)
    sellable = Column(Boolean, default=True)
    chest_drop = Column(Boolean, default=True)
    is_limited = Column(Boolean, default=False)   # if True, only purchasable/droppable during an active FeaturedDrop window
    visibility_rule = Column(String, default="public")   # "public" | "permission"

    created_at = Column(DateTime, default=datetime.utcnow)

    ownerships = relationship("CardOwnership", back_populates="template")

    def public_dict(self):
        return {
            "id": self.id, "code": self.code, "name": self.name, "rarity": self.rarity,
            "image_url": self.image_url, "base_price_diamond": self.base_price_diamond,
            "base_price_ball": self.base_price_ball, "sellable": self.sellable,
            "is_limited": self.is_limited,
        }


class CardOwnership(Base):
    """A specific copy of a card owned by a specific user."""
    __tablename__ = "card_ownerships"

    id = Column(Integer, primary_key=True)
    template_id = Column(Integer, ForeignKey("card_templates.id"), nullable=False)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    acquired_at = Column(DateTime, default=datetime.utcnow)

    template = relationship("CardTemplate", back_populates="ownerships")
    owner = relationship("User", back_populates="cards")


class MarketListing(Base):
    """A card a user has put up for sale (peer-to-peer market)."""
    __tablename__ = "market_listings"

    id = Column(Integer, primary_key=True)
    ownership_id = Column(Integer, ForeignKey("card_ownerships.id"), nullable=False)
    seller_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    price_ball = Column(Integer, nullable=False)
    ai_suggested_price = Column(Float, nullable=True)
    status = Column(String, default="active")   # active | sold | cancelled
    created_at = Column(DateTime, default=datetime.utcnow)
    sold_at = Column(DateTime, nullable=True)

    ownership = relationship("CardOwnership")
    seller = relationship("User")
