from datetime import datetime

from sqlalchemy import Column, Integer, DateTime

from app.core.database import Base


class JackpotPool(Base):
    """
    Single-row table: the current casino jackpot pool (Ball). Grows a bit on
    every 'jackpot' game spin — win or lose — and pays out in full (then
    resets to JACKPOT_BASE_BALL) when a player lands three 🎰 symbols.
    """
    __tablename__ = "jackpot_pool"

    id = Column(Integer, primary_key=True)
    amount = Column(Integer, default=5000)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
