from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from app.core.database import Base


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True)
    room = Column(String, default="global")   # global | trade | support | ...
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    text = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")

    def public_dict(self):
        return {
            "id": self.id, "room": self.room, "user_id": self.user_id,
            "name": self.user.name if self.user else "?",
            "avatar_url": self.user.avatar_url if self.user else "",
            "rank_title": self.user.rank_title if self.user else "",
            "level": self.user.level if self.user else 1,
            "text": self.text, "created_at": self.created_at.isoformat(),
        }
