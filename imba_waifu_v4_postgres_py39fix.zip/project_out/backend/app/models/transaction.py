from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from app.core.database import Base


class Transaction(Base):
    """
    Every balance change is logged here (spec: 02_ECONOMY...md section 6).
    Never trust the frontend's number — this table is the source of truth.
    """
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    type = Column(String, nullable=False)          # daily_bonus, chest_open, market_buy, market_sell, game_win, game_lose, mission
    currency = Column(String, default="ball")       # ball | diamond | keys | xp | achko
    amount = Column(Integer, nullable=False)        # can be negative
    before_balance = Column(Integer, nullable=False)
    after_balance = Column(Integer, nullable=False)
    source = Column(String, default="system")       # system | user | admin
    note = Column(String, nullable=True)            # optional: admin:id, game:key
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="transactions")
