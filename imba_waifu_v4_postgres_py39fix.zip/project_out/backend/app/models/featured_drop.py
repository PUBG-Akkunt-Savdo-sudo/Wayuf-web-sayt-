from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship

from app.core.database import Base


class FeaturedDrop(Base):
    """
    A time-limited window during which a `is_limited=True` card is
    actually purchasable/droppable — like a rotating rare weapon/skin in
    PUBG/DLS. When the window ends, `resolve_expired_drops()` (see
    services/drop_service.py) decides whether the card returns for
    another window or retires, based on a configurable probability —
    this is a simple rule, not a real AI model, and is labeled as such
    everywhere it's shown.
    """
    __tablename__ = "featured_drops"

    id = Column(Integer, primary_key=True)
    card_template_id = Column(Integer, ForeignKey("card_templates.id"), nullable=False)
    starts_at = Column(DateTime, default=datetime.utcnow)
    ends_at = Column(DateTime, nullable=False)
    status = Column(String, default="active")   # active | returning | retired
    auto_decided = Column(Boolean, default=False)  # True if the return/retire call was made by the rule engine, not an admin
    resolved_at = Column(DateTime, nullable=True)
    created_by_admin_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    card = relationship("CardTemplate")

    def public_dict(self):
        return {
            "id": self.id, "card": self.card.public_dict() if self.card else None,
            "starts_at": self.starts_at.isoformat(), "ends_at": self.ends_at.isoformat(),
            "status": self.status, "auto_decided": self.auto_decided,
        }
