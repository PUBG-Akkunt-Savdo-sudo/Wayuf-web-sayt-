from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime

from app.core.database import Base


class AdminSetting(Base):
    """
    Simple key-value store for admin-configurable settings, e.g. the
    Gemini API key used for AI card-art generation. Keeping it in the DB
    (instead of .env) means the admin can change it from the panel without
    redeploying.
    """
    __tablename__ = "admin_settings"

    id = Column(Integer, primary_key=True)
    key = Column(String, unique=True, index=True, nullable=False)
    value = Column(String, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
