"""
Run once after first setting up the DB:
    cd backend && python seed_cards.py

Populates the card_templates table so Home/Cards/Market/Chest have real
content instead of an empty catalog.
"""
from app.core.database import SessionLocal, init_db
from app.models.card import CardTemplate

CARDS = [
    dict(code="GX-01", name="Galaxy Emilia", rarity="Galaxy", base_price_diamond=12450, base_price_ball=120000),
    dict(code="LG-02", name="Legend Rem", rarity="Legend", base_price_diamond=9750, base_price_ball=95000),
    dict(code="SP-03", name="Special ZeroTwo", rarity="Special", base_price_diamond=7320, base_price_ball=75000),
    dict(code="RR-04", name="Rare Miku", rarity="Rare", base_price_diamond=3100, base_price_ball=32000),
    dict(code="OD-05", name="Oddiy Asuna", rarity="Ordinary", base_price_diamond=900, base_price_ball=8500),
    dict(code="GX-06", name="Galaxy Hinata", rarity="Galaxy", base_price_diamond=11800, base_price_ball=118000),
    dict(code="RR-07", name="Rare Mikasa", rarity="Rare", base_price_diamond=2800, base_price_ball=27500),
    dict(code="SP-08", name="Special Yor", rarity="Special", base_price_diamond=6900, base_price_ball=68000),
]


def run():
    init_db()
    db = SessionLocal()
    added = 0
    for c in CARDS:
        exists = db.query(CardTemplate).filter(CardTemplate.code == c["code"]).first()
        if not exists:
            db.add(CardTemplate(**c))
            added += 1
    db.commit()
    db.close()
    print(f"Seeded {added} new card templates ({len(CARDS) - added} already existed).")


if __name__ == "__main__":
    run()
