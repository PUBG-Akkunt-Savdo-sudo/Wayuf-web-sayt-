"""
IMBA WAIFU Telegram bot — aiogram 3.x.
Its only job is: greet the user and open the Mini App. All game/economy
logic lives in backend/ (the mini app talks to it directly over HTTP).

Run:
    pip install aiogram python-dotenv
    export BOT_TOKEN=xxxx
    export MINIAPP_URL=https://pubg-akkunt-savdo-sudo.github.io/Wayuf-web-sayt/
    python bot/app.py
"""
import asyncio
import logging
import os

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
MINIAPP_URL = os.getenv("MINIAPP_URL", "https://pubg-akkunt-savdo-sudo.github.io/Wayuf-web-sayt/")
ADMIN_URL = os.getenv("ADMIN_URL", "https://pubg-akkunt-savdo-sudo.github.io/Wayuf-web-sayt/admin/")

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


def miniapp_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌌 Open IMBA WAIFU", web_app=WebAppInfo(url=MINIAPP_URL))]
    ])


@dp.message(CommandStart())
async def start_handler(message: Message):
    await message.answer(
        "✨ <b>IMBA WAIFU</b>ga xush kelibsiz!\n\n"
        "Anime kartalarni yig'ing, savdo qiling, o'yinlar o'ynang va reytingda ko'tariling.\n\n"
        "Boshlash uchun quyidagi tugmani bosing 👇",
        reply_markup=miniapp_keyboard(),
        parse_mode="HTML",
    )


@dp.message(F.text == "/app")
async def app_shortcut(message: Message):
    await message.answer("Mini App:", reply_markup=miniapp_keyboard())


@dp.message(F.text == "/admin")
async def admin_shortcut(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛠 Admin Panel", web_app=WebAppInfo(url=ADMIN_URL))]
    ])
    await message.answer(
        "Admin panel faqat OWNER_TELEGRAM_ID sifatida sozlangan hisobga ochiladi — "
        "boshqa foydalanuvchilarga backend 403 qaytaradi.",
        reply_markup=kb,
    )


async def main():
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN environment variable is not set")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
