#!/bin/bash
# ════════════════════════════════════════════════════════════════
#  deploy.sh — IMBA WAIFU production deploy
#
#  Ishlatish (birinchi marta):
#    sudo bash setup_postgres.sh   # PostgreSQL o'rnatish
#    bash deploy.sh                # backend + bot ishga tushirish
#
#  Keyingi yangilanishlar:
#    bash deploy.sh
# ════════════════════════════════════════════════════════════════
set -e
GREEN="\033[32m"; YELLOW="\033[33m"; NC="\033[0m"
ok()   { echo -e "${GREEN}✅ $*${NC}"; }
info() { echo -e "${YELLOW}ℹ️  $*${NC}"; }

PROJ_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$PROJ_DIR/backend"
BOT_DIR="$PROJ_DIR/bot"
ENV_FILE="$PROJ_DIR/.env"

# ── Tekshiruvlar ─────────────────────────────────────────────────
[ -f "$ENV_FILE" ] || { echo "❌ .env topilmadi! .env.example dan nusxa oling."; exit 1; }
source "$ENV_FILE"
[ -z "$BOT_TOKEN"    ] && { echo "❌ BOT_TOKEN bo'sh!";          exit 1; }
[ -z "$DATABASE_URL" ] && { echo "❌ DATABASE_URL bo'sh!";       exit 1; }
echo "$DATABASE_URL" | grep -q "postgresql" || { echo "❌ DATABASE_URL postgresql:// bo'lishi kerak!"; exit 1; }
ok "Tekshiruvlar o'tdi"

# ── Python paketlari ──────────────────────────────────────────────
info "Paketlar o'rnatilmoqda..."
pip install -q -r "$BACKEND_DIR/requirements.txt" --break-system-packages
pip install -q -r "$BOT_DIR/requirements.txt"     --break-system-packages 2>/dev/null || true
ok "Paketlar o'rnatildi"

# ── DB jadvallarini yaratish ──────────────────────────────────────
info "DB jadvallari tekshirilmoqda..."
cd "$BACKEND_DIR"
PYTHONPATH="$PROJ_DIR:$BACKEND_DIR" python -c "
from app.core.database import init_db
init_db()
"
ok "DB tayyor"

# ── Eski screen sessionlarni to'xtatish ──────────────────────────
for sess in wayuf_backend wayuf_bot wayuf_tunnel; do
    screen -S "$sess" -X quit 2>/dev/null || true
done
sleep 1

# ── Backend (FastAPI) ─────────────────────────────────────────────
info "Backend ishga tushirilmoqda..."
screen -dmS wayuf_backend bash -c "
    cd $BACKEND_DIR
    PYTHONPATH=$PROJ_DIR:$BACKEND_DIR \
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2 --no-access-log
"
sleep 2
curl -sf http://localhost:8000/api/health > /dev/null \
    && ok "Backend ishlayapti (port 8000)" \
    || echo -e "${YELLOW}⚠️  Backend hali yuklanmoqda...${NC}"

# ── Bot ───────────────────────────────────────────────────────────
info "Bot ishga tushirilmoqda..."
screen -dmS wayuf_bot bash -c "
    cd $BOT_DIR
    PYTHONPATH=$PROJ_DIR:$BOT_DIR python app.py
"
sleep 2
ok "Bot ishga tushdi"

# ── Tunnel (cloudflared) ─────────────────────────────────────────
if command -v cloudflared &>/dev/null; then
    info "Tunnel ishga tushirilmoqda..."
    screen -dmS wayuf_tunnel cloudflared tunnel --url http://localhost:8000
    sleep 3
    ok "Tunnel ishga tushdi"
else
    echo -e "${YELLOW}ℹ️  cloudflared topilmadi — tunnel qo'lda ishga tushirilsin${NC}"
fi

# ── Holat ────────────────────────────────────────────────────────
echo ""
screen -ls
echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}  IMBA WAIFU muvaffaqiyatli ishga tushdi!${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo "  Backend : http://localhost:8000"
echo "  API doc : http://localhost:8000/docs"
echo ""
echo "Loglarni ko'rish:"
echo "  screen -r wayuf_backend"
echo "  screen -r wayuf_bot"
echo "  screen -r wayuf_tunnel"
