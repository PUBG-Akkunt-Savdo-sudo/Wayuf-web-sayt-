#!/bin/bash
# ════════════════════════════════════════════════════════════════
#  setup_postgres.sh — Ubuntu serverda PostgreSQL o'rnatish
#  va IMBA WAIFU uchun DB yaratish
#
#  Ishlatish:
#    chmod +x setup_postgres.sh
#    sudo bash setup_postgres.sh
# ════════════════════════════════════════════════════════════════
set -e

GREEN="\033[32m"; YELLOW="\033[33m"; RED="\033[31m"; NC="\033[0m"
ok()   { echo -e "${GREEN}✅ $*${NC}"; }
info() { echo -e "${YELLOW}ℹ️  $*${NC}"; }
err()  { echo -e "${RED}❌ $*${NC}"; exit 1; }

# ── 1. PostgreSQL o'rnatish ──────────────────────────────────────
info "PostgreSQL o'rnatilmoqda..."
apt-get update -qq
apt-get install -y postgresql postgresql-contrib
systemctl enable postgresql
systemctl start postgresql
ok "PostgreSQL o'rnatildi va ishga tushdi"

# ── 2. DB foydalanuvchisi va bazasi yaratish ─────────────────────
DB_USER="waifu"
DB_NAME="imbawaifu"

# Tasodifiy kuchli parol yaratish
DB_PASS=$(openssl rand -base64 24 | tr -d '/+=')

info "DB foydalanuvchisi va bazasi yaratilmoqda..."
sudo -u postgres psql -c "
  DO \$\$
  BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${DB_USER}') THEN
      CREATE ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASS}';
    ELSE
      ALTER ROLE ${DB_USER} WITH PASSWORD '${DB_PASS}';
    END IF;
  END
  \$\$;
"
sudo -u postgres psql -c "
  SELECT 'CREATE DATABASE ${DB_NAME} OWNER ${DB_USER}'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${DB_NAME}')
" | grep -q "CREATE DATABASE" && \
  sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};" || \
  info "Baza allaqachon mavjud"

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};"
ok "DB yaratildi: ${DB_NAME}"

# ── 3. pg_hba.conf — local ulanishga ruxsat ─────────────────────
PG_VERSION=$(pg_lscluster | awk 'NR>1{print $1; exit}')
PG_HBA="/etc/postgresql/${PG_VERSION}/main/pg_hba.conf"

if ! grep -q "host.*${DB_NAME}.*${DB_USER}" "$PG_HBA"; then
  echo "host    ${DB_NAME}    ${DB_USER}    127.0.0.1/32    md5" >> "$PG_HBA"
  systemctl reload postgresql
  ok "pg_hba.conf yangilandi"
fi

# ── 4. .env faylini yangilash ────────────────────────────────────
ENV_FILE="/root/project_out/.env"
if [ -f "$ENV_FILE" ]; then
  # DATABASE_URL ni o'zgartirish
  sed -i "s|DATABASE_URL=.*|DATABASE_URL=postgresql://${DB_USER}:${DB_PASS}@127.0.0.1:5432/${DB_NAME}|" "$ENV_FILE"
  ok ".env yangilandi"
else
  info ".env topilmadi. Quyidagi qiymatni qo'shing:"
fi

# ── 5. Natija ────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}  PostgreSQL muvaffaqiyatli sozlandi!   ${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo ""
echo "  DB nomi     : ${DB_NAME}"
echo "  Foydalanuvchi: ${DB_USER}"
echo "  Parol       : ${DB_PASS}"
echo ""
echo "  .env uchun DATABASE_URL:"
echo "  postgresql://${DB_USER}:${DB_PASS}@127.0.0.1:5432/${DB_NAME}"
echo ""
echo -e "${YELLOW}⚠️  Parolni xavfsiz joyda saqlang!${NC}"
